# PDF Compare Tool

Tool untuk membandingkan data Laporan Transaksi (PDF) hasil generate sistem dengan data Excel yang di-extract dari database, berdasarkan skenario test case.

## Fitur

- Ekstraksi PDF berbasis anchor text (tidak bergantung pada koordinat absolut atau nomor halaman)
- Mendukung tabel multi-page (auto-stitch antar halaman)
- Compare otomatis untuk 6 section: Nama & Alamat, Informasi Polis, Laporan Transaksi, Estimasi Nilai Polis, Rincian Laporan Transaksi, dan Informasi Jatuh Tempo
- Batch processing untuk banyak polis sekaligus berdasarkan file test case
- Output detail per polis (warna PASS/FAIL/ERROR) dan summary keseluruhan

## Struktur Folder

```
pdf_compare/
├── main.py                      # Entry point — jalankan file ini
├── requirements.txt
├── extractor/                   # Ekstraksi data dari PDF
│   ├── utils.py                 # Normalisasi angka, tanggal, anchor, grouping baris
│   ├── extract_nama_alamat.py
│   ├── extract_info_polis.py
│   ├── extract_laporan_transaksi.py
│   ├── extract_estimasi_nilai_polis.py
│   ├── extract_rincian_transaksi.py
│   └── extract_jatuh_tempo.py
├── comparator/                  # Pembacaan Excel & logika compare
│   ├── excel_reader.py          # Baca semua sheet Excel DB
│   └── comparator.py            # Compare per section
├── reporter/                    # Generate file output Excel
│   └── reporter.py
└── resource/
    └── data/
        ├── pdf/                 # Input: laporan_{policy_no}.pdf
        ├── excel/                # Input: data_{policy_no}.xlsx
        └── testcase/             # Input: testcase.xlsx
```

Folder `results/{datetime}/` akan dibuat otomatis setiap kali script dijalankan, berisi:
- `testcase_summary.xlsx` — ringkasan jumlah executed/pass/fail/error/skip per test case
- `detail/{policy_no}_compare.xlsx` — detail hasil compare per field, per polis

## Instalasi

```bash
pip install -r requirements.txt
```

## Cara Pakai

1. Letakkan file PDF di `resource/data/pdf/` dengan nama `laporan_{policy_no}.pdf`
2. Letakkan file Excel DB di `resource/data/excel/` dengan nama `data_{policy_no}.xlsx`
3. Isi `resource/data/testcase/testcase.xlsx` dengan kolom: `test_case_id`, `policy_number`, `product_code`, `skip` (Y/N)
4. Jalankan:
   ```bash
   python main.py
   ```
5. Cek hasil di `results/{datetime}/`

## Konfirmasi Mapping Kolom Excel → PDF

### Sheet "Laporan Transaksi"
| Field PDF | Kolom Excel |
|---|---|
| Jumlah Unit | `closing_unit` |
| Harga Unit | `bid_price` |

### Sheet "RINCIAN LAPORAN TRANSAKSI"
| Field PDF | Kolom Excel |
|---|---|
| Jumlah Unit (baris transaksi) | `transaction_in_unit` |
| Harga Unit (baris transaksi) | `unit_price` |
| Jumlah Unit (Saldo Akhir) | `closing_unit` |
| Harga Unit (Saldo Akhir) | `bid_price` |
| Tanggal Harga Unit | `u_l_fund_price_date` (format disesuaikan) |
| Biaya Lump Sum Diawal & Lump Sum Awal | **di-ignore**, tidak dicompare |

Composite key untuk matching baris Rincian Transaksi antara PDF dan Excel: `transaction_date` + `transaction_code` + `fund_description`. Jika masih ada duplikat, urutan baris dipakai sebagai tiebreaker.

## Aturan Compare

- **Field numerik** (Laporan Transaksi & Rincian Laporan Transaksi): exact match dengan pembulatan **2 angka desimal**, format float disamakan antara PDF dan Excel.
- **Field numerik lain** (Estimasi Nilai Polis, Jatuh Tempo): pembulatan 4 angka desimal.
- **Field tanggal**: disamakan ke format Indonesia (`DD Month YYYY`) sebelum dibandingkan.
- **Formula Excel** (`cash_value`, `Jumlah Unit * Harga Unit`): tidak dibaca sebagai string formula, melainkan menggunakan kolom hasil hitung yang sudah tersedia di DB (`investment_value`, `transaction_amount_in_fund_ccy`).

## Status Hasil Compare

| Status | Keterangan |
|---|---|
| PASS | Nilai PDF = nilai Excel |
| FAIL | Nilai PDF ≠ nilai Excel |
| ERROR | Proses ekstraksi/baca data gagal (exception), detail di kolom remark |
| SKIP | Test case di-skip manual via kolom `skip=Y` di file testcase |

## Catatan Penting

PDF sample yang dipakai untuk pengembangan saat ini di-generate dari Microsoft Word. Jika sistem produksi menghasilkan PDF dari engine berbasis HTML (WeasyPrint, wkhtmltopdf, Puppeteer, dll), perilaku ekstraksi tabel dan posisi anchor perlu divalidasi ulang menggunakan sample PDF asli — terutama untuk kasus tabel yang meluber ke lebih dari satu halaman.
