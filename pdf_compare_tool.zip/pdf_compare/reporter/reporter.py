import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


# ── COLOR CONSTANTS ────────────────────────────────────────────────────────────
CLR_HEADER_BG   = "1F4E79"  # Dark blue - section header
CLR_HEADER_FG   = "FFFFFF"
CLR_COL_HEADER  = "2E75B6"  # Medium blue - column header
CLR_PASS        = "E2EFDA"  # Green bg
CLR_FAIL        = "FCE4D6"  # Red bg
CLR_ERROR       = "FFF2CC"  # Yellow bg
CLR_FONT_FAIL   = "C00000"
CLR_FONT_PASS   = "375623"
CLR_FONT_ERROR  = "7F6000"

THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

COLUMNS = ["section", "field", "nilai_pdf", "nilai_excel", "status", "remark"]
COL_WIDTHS = [28, 45, 22, 22, 10, 45]


def _apply_cell(cell, value, bold=False, bg=None, fg="000000", wrap=False, center=False):
    cell.value = value
    cell.font = Font(name="Arial", bold=bold, color=fg, size=10)
    if bg:
        cell.fill = PatternFill("solid", start_color=bg)
    cell.border = BORDER
    cell.alignment = Alignment(
        wrap_text=wrap,
        horizontal="center" if center else "left",
        vertical="center"
    )


def write_detail_report(results: list, output_path: str, policy_no: str):
    """
    Tulis file detail compare per polis.
    Format: 1 sheet, dipisah per section dengan sub-header.
    """
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = f"Compare {policy_no}"

    # Set column widths
    for i, width in enumerate(COL_WIDTHS, 1):
        ws.column_dimensions[get_column_letter(i)].width = width

    # Title
    ws.row_dimensions[1].height = 20
    title_cell = ws.cell(row=1, column=1, value=f"Compare Report — No. Polis: {policy_no}")
    title_cell.font = Font(name="Arial", bold=True, size=12, color="1F4E79")
    title_cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=6)

    # Column header row
    ws.row_dimensions[2].height = 18
    for col_idx, col_name in enumerate(COLUMNS, 1):
        cell = ws.cell(row=2, column=col_idx, value=col_name.upper().replace("_", " "))
        _apply_cell(cell, col_name.upper().replace("_", " "),
                    bold=True, bg=CLR_COL_HEADER, fg=CLR_HEADER_FG, center=True)

    current_row = 3

    for item in results:
        ws.row_dimensions[current_row].height = 16

        is_section_header = (item["field"] == "" and item["status"] == "")
        status = item.get("status", "")

        for col_idx, col_name in enumerate(COLUMNS, 1):
            cell = ws.cell(row=current_row, column=col_idx)
            value = item.get(col_name, "")

            if is_section_header:
                # Section header row: merge kolom section, bold, dark blue
                _apply_cell(cell, value if col_idx == 1 else "",
                            bold=True, bg=CLR_HEADER_BG, fg=CLR_HEADER_FG)
            else:
                if status == "PASS":
                    bg = CLR_PASS
                    fg = CLR_FONT_PASS
                elif status == "FAIL":
                    bg = CLR_FAIL
                    fg = CLR_FONT_FAIL
                elif status == "ERROR":
                    bg = CLR_ERROR
                    fg = CLR_FONT_ERROR
                else:
                    bg = None
                    fg = "000000"

                is_status_col = (col_name == "status")
                _apply_cell(cell, value,
                            bold=is_status_col,
                            bg=bg, fg=fg,
                            wrap=(col_name == "remark"),
                            center=is_status_col)

        if is_section_header:
            ws.merge_cells(
                start_row=current_row, start_column=1,
                end_row=current_row, end_column=6
            )

        current_row += 1

    # Freeze panes
    ws.freeze_panes = "A3"

    wb.save(output_path)


def write_summary_report(summary_rows: list, output_path: str):
    """
    Tulis/update file summary testcase.
    Kolom: test_case_id | policy_number | product_code | skip | status | executed | pass | fail | error | skip_count | remark
    """
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Summary"

    headers = [
        "test_case_id", "policy_number", "product_code", "skip",
        "status", "executed", "pass", "fail", "error", "skip_count", "remark"
    ]
    col_widths = [14, 16, 16, 8, 10, 10, 8, 8, 8, 10, 45]

    for i, width in enumerate(col_widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = width

    # Title
    ws.row_dimensions[1].height = 20
    tc = ws.cell(row=1, column=1, value="Test Case Summary Report")
    tc.font = Font(name="Arial", bold=True, size=12, color="1F4E79")
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(headers))

    # Column headers
    ws.row_dimensions[2].height = 18
    for col_idx, h in enumerate(headers, 1):
        cell = ws.cell(row=2, column=col_idx, value=h.upper().replace("_", " "))
        _apply_cell(cell, h.upper().replace("_", " "),
                    bold=True, bg=CLR_COL_HEADER, fg=CLR_HEADER_FG, center=True)

    # Data rows
    current_row = 3
    total_executed = total_pass = total_fail = total_error = total_skip = 0

    for sr in summary_rows:
        ws.row_dimensions[current_row].height = 16
        status = sr.get("status", "")

        if status == "SKIP":
            bg = "D9D9D9"
        elif status == "PASS":
            bg = CLR_PASS
        elif status == "FAIL":
            bg = CLR_FAIL
        elif status == "ERROR":
            bg = CLR_ERROR
        else:
            bg = None

        values = [
            sr.get("test_case_id"),
            sr.get("policy_number"),
            sr.get("product_code"),
            sr.get("skip"),
            status,
            sr.get("executed", 0),
            sr.get("pass", 0),
            sr.get("fail", 0),
            sr.get("error", 0),
            sr.get("skip_count", 0),
            sr.get("remark", ""),
        ]

        for col_idx, val in enumerate(values, 1):
            cell = ws.cell(row=current_row, column=col_idx, value=val)
            is_status = (col_idx == 5)
            _apply_cell(cell, val, bold=is_status, bg=bg,
                        fg=CLR_FONT_FAIL if status == "FAIL" else
                           CLR_FONT_PASS if status == "PASS" else
                           CLR_FONT_ERROR if status == "ERROR" else "000000",
                        center=is_status,
                        wrap=(col_idx == len(headers)))

        # Hitung totals
        if status != "SKIP":
            total_executed += sr.get("executed", 0)
            total_pass     += sr.get("pass", 0)
            total_fail     += sr.get("fail", 0)
            total_error    += sr.get("error", 0)
        else:
            total_skip += 1

        current_row += 1

    # Grand total row
    ws.row_dimensions[current_row].height = 18
    grand_vals = ["", "", "", "TOTAL", "", total_executed, total_pass, total_fail, total_error, total_skip, ""]
    for col_idx, val in enumerate(grand_vals, 1):
        cell = ws.cell(row=current_row, column=col_idx, value=val)
        _apply_cell(cell, val, bold=True, bg="D6DCE4", center=True)

    ws.freeze_panes = "A3"
    wb.save(output_path)
