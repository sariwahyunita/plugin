import pdfplumber
from .utils import find_anchor_page, normalize_number


def extract_jatuh_tempo(pdf: pdfplumber.PDF) -> dict:
    """
    Extract tabel Informasi Jatuh Tempo (posisi halaman dinamis).
    Anchor: 'Premi Dasar' (header kolom tabel)
    Output: {basic_premi, rider, top_up, extra_premi, total_premi,
             due_date, payment_mode, account_number}
    """
    page_idx = find_anchor_page(pdf, "Premi Dasar")
    if page_idx == -1:
        raise ValueError("Anchor 'Premi Dasar' tidak ditemukan di PDF")

    page = pdf.pages[page_idx]
    tables = page.extract_tables()

    target_table = None
    for table in tables:
        flat = " ".join(str(cell) for row in table for cell in row if cell)
        if "Premi Dasar" in flat and "Total Premi" in flat:
            target_table = table
            break

    if target_table is None:
        raise ValueError("Tabel Informasi Jatuh Tempo tidak ditemukan di PDF")

    # Tabel 2 baris: baris 0 = header, baris 1 = data
    data_row = None
    for row in target_table:
        cells = [c.replace("\n", " ").strip() if c else "" for c in row]
        # Skip header row
        if "Premi Dasar" in " ".join(cells):
            continue
        non_empty = [c for c in cells if c]
        if non_empty:
            data_row = cells
            break

    if data_row is None:
        raise ValueError("Baris data Informasi Jatuh Tempo tidak ditemukan")

    # Kolom: basic_premi | rider | top_up | extra_premi | total_premi | due_date | payment_mode | account_number
    def get_cell(idx):
        return data_row[idx].strip() if idx < len(data_row) else None

    return {
        "basic_premi":      normalize_number(get_cell(0)),
        "rider":            normalize_number(get_cell(1)),
        "top_up":           normalize_number(get_cell(2)),
        "extra_premi":      normalize_number(get_cell(3)),
        "total_premi":      normalize_number(get_cell(4)),
        "due_date":         get_cell(5),
        "payment_mode":     get_cell(6),
        "account_number":   get_cell(7),
    }
