from datetime import datetime
import re

BULAN_ID = {
    "Januari": 1, "Februari": 2, "Maret": 3, "April": 4,
    "Mei": 5, "Juni": 6, "Juli": 7, "Agustus": 8,
    "September": 9, "Oktober": 10, "November": 11, "Desember": 12
}

BULAN_EN = {
    1: "Januari", 2: "Februari", 3: "Maret", 4: "April",
    5: "Mei", 6: "Juni", 7: "Juli", 8: "Agustus",
    9: "September", 10: "Oktober", 11: "November", 12: "Desember"
}


def normalize_number(text: str) -> float:
    """
    Convert Indonesian/mixed number format string to float.
    Handles:
    - Rupiah format: '398.631,62' -> 398631.62  (titik=ribuan, koma=desimal)
    - Unit format:   '48.6887'    -> 48.6887     (titik=desimal)
    - Negative:      '(48.6887)'  -> -48.6887
    - Negative:      '(345.000,00)' -> -345000.0
    """
    if text is None:
        return None
    text = str(text).strip()

    # Handle format negatif (angka)
    negative = text.startswith("(") and text.endswith(")")
    if negative:
        text = text[1:-1]

    # Bersihkan prefix Rp
    text = text.replace("Rp.", "").replace("Rp", "").strip()

    value = None

    # Kasus 1: ada koma dan titik keduanya → deteksi format
    if "," in text and "." in text:
        comma_pos = text.rfind(",")
        dot_pos   = text.rfind(".")
        if dot_pos > comma_pos:
            # Titik setelah koma terakhir → format EN: koma=ribuan, titik=desimal
            # Contoh: '25,000.00' → 25000.0
            cleaned = text.replace(",", "")
            try:
                value = float(cleaned)
            except ValueError:
                pass
        else:
            # Koma setelah titik terakhir → format ID: titik=ribuan, koma=desimal
            # Contoh: '398.631,62' → 398631.62
            cleaned = text.replace(".", "").replace(",", ".")
            try:
                value = float(cleaned)
            except ValueError:
                pass

    # Kasus 2: ada koma saja → koma sebagai desimal (format unit kecil)
    elif "," in text and "." not in text:
        cleaned = text.replace(",", ".")
        try:
            value = float(cleaned)
        except ValueError:
            pass

    # Kasus 3: ada titik saja → deteksi apakah titik = ribuan atau desimal
    elif "." in text and "," not in text:
        parts = text.split(".")
        # Jika bagian setelah titik terakhir = 3 digit dan ada lebih dari 1 titik → ribuan
        # Contoh: '15.000.000' → ribuan
        # Jika bagian setelah titik bukan 3 digit → desimal
        # Contoh: '48.6887' → desimal, '513.4652' → desimal
        last_part = parts[-1]
        if len(parts) > 2 or (len(last_part) == 3 and len(parts) == 2 and len(parts[0]) <= 3):
            # Kemungkinan format ribuan: '25.000', '15.000.000'
            cleaned = text.replace(".", "")
            try:
                value = float(cleaned)
            except ValueError:
                pass
        else:
            # Titik sebagai desimal: '48.6887', '513.4652'
            try:
                value = float(text)
            except ValueError:
                pass

    # Kasus 4: tidak ada titik dan tidak ada koma → integer
    else:
        try:
            value = float(text)
        except ValueError:
            pass

    if value is None:
        return None
    return -value if negative else value


def normalize_date_to_str(value) -> str:
    """
    Convert any date representation to Indonesian date string.
    Handles: datetime object, Excel serial, string 'DD Month YYYY', string 'YYYY-MM-DD'
    Returns: 'DD Month YYYY' e.g. '07 Mei 2026'
    """
    if value is None:
        return None

    # Already datetime object
    if isinstance(value, datetime):
        return f"{value.day:02d} {BULAN_EN[value.month]} {value.year}"

    # String handling
    text = str(value).strip()

    # Already Indonesian format: '07 Mei 2026'
    pattern_id = re.match(r"(\d{1,2})\s+(\w+)\s+(\d{4})", text)
    if pattern_id:
        day = int(pattern_id.group(1))
        month_str = pattern_id.group(2)
        year = int(pattern_id.group(3))
        if month_str in BULAN_ID:
            return f"{day:02d} {month_str} {year}"

    # ISO format: '2026-05-07' or '2026-05-07 00:00:00'
    pattern_iso = re.match(r"(\d{4})-(\d{2})-(\d{2})", text)
    if pattern_iso:
        year = int(pattern_iso.group(1))
        month = int(pattern_iso.group(2))
        day = int(pattern_iso.group(3))
        return f"{day:02d} {BULAN_EN[month]} {year}"

    return text


def find_anchor_page(pdf, anchor_text: str) -> int:
    """Find page index (0-based) containing anchor_text. Returns -1 if not found."""
    for i, page in enumerate(pdf.pages):
        text = page.extract_text() or ""
        if anchor_text in text:
            return i
    return -1


def group_words_by_row(words: list, tolerance: float = 3.0) -> list:
    """
    Group words into rows based on y-coordinate proximity.
    Returns list of rows, each row is list of word dicts sorted by x0.
    """
    if not words:
        return []

    rows = []
    current_row = [words[0]]
    current_y = words[0]["top"]

    for word in words[1:]:
        if abs(word["top"] - current_y) <= tolerance:
            current_row.append(word)
        else:
            rows.append(sorted(current_row, key=lambda w: w["x0"]))
            current_row = [word]
            current_y = word["top"]

    if current_row:
        rows.append(sorted(current_row, key=lambda w: w["x0"]))

    return rows


def row_to_text(row: list) -> str:
    """Join words in a row to single string."""
    return " ".join(w["text"] for w in row)


def round4(value) -> float:
    """Round float to 4 decimal places."""
    if value is None:
        return None
    return round(float(value), 4)


def round2(value) -> float:
    """Round float to 2 decimal places."""
    if value is None:
        return None
    return round(float(value), 2)
