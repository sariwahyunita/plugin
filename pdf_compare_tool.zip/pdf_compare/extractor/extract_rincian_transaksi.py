import pdfplumber
from .utils import find_anchor_page, normalize_number, normalize_date_to_str


SKIP_TRANSACTION_CODES = {"Biaya Lump Sum Diawal", "Lump Sum Awal"}

HEADER_KEYWORDS = {
    "Tanggal Transaksi", "Jenis Transaksi", "Tanggal Harga Unit",
    "Jumlah Unit", "Harga Unit", "Jumlah Nilai Transaksi"
}


def _is_header_row(cells: list) -> bool:
    joined = " ".join(c for c in cells if c)
    return any(kw in joined for kw in HEADER_KEYWORDS)


def _is_skip_row(cells: list) -> bool:
    joined = " ".join(c for c in cells if c)
    return any(skip in joined for skip in SKIP_TRANSACTION_CODES)


def _is_saldo_row(cells: list, label: str) -> bool:
    return any(label in (c or "") for c in cells)


def _is_data_row(cells: list) -> bool:
    """Baris data valid: ada nilai numerik dan bukan header/skip/saldo"""
    non_empty = [c for c in cells if c and c.strip()]
    if len(non_empty) < 3:
        return False
    has_numeric = any(
        c.replace(".", "").replace(",", "").replace("-", "")
         .replace("(", "").replace(")", "").strip().isdigit()
        for c in non_empty
    )
    return has_numeric


def extract_rincian_transaksi(pdf: pdfplumber.PDF) -> dict:
    """
    Extract tabel Rincian Laporan Transaksi (multi-page aware).
    Anchor start: 'Rincian Transaksi per'
    Anchor end  : 'Saldo Akhir'
    Skip rows   : Biaya Lump Sum Diawal, Lump Sum Awal
    Composite key untuk matching: transaction_date + transaction_code + fund_description

    Output: {
        from_period, to_period, opening_unit,
        rows: [{transaction_date, transaction_code, fund_description,
                price_date, jumlah_unit, harga_unit, amount}],
        closing: {nav_date, harga_unit, jumlah_unit, investment_value}
    }
    """
    start_page_idx = find_anchor_page(pdf, "Rincian Transaksi per")
    if start_page_idx == -1:
        raise ValueError("Anchor 'Rincian Transaksi per' tidak ditemukan di PDF")

    # Kumpulkan semua baris dari semua halaman yang relevan
    all_rows_raw = []
    from_period = None
    to_period = None
    opening_unit = None
    closing = None
    found_end = False
    first_page_header_cells = None
    current_fund = None

    for page_idx in range(start_page_idx, len(pdf.pages)):
        page = pdf.pages[page_idx]
        tables = page.extract_tables()

        # Cari tabel yang relevan di halaman ini
        target_table = None
        for table in tables:
            flat = " ".join(str(cell) for row in table for cell in row if cell)
            if "Rincian Transaksi per" in flat or "Saldo Akhir" in flat or (
                page_idx > start_page_idx and "Saldo Awal" not in flat and len(table) > 2
            ):
                target_table = table
                break

        if target_table is None:
            # Halaman ini tidak punya tabel rincian, cek apakah sudah lewat section
            page_text = page.extract_text() or ""
            if page_idx > start_page_idx and "Informasi Jatuh Tempo" in page_text:
                break
            continue

        for row in target_table:
            cells = [c.replace("\n", " ").strip() if c else "" for c in row]

            # Ambil from_period dan to_period dari baris header tabel
            joined = " ".join(c for c in cells if c)
            if "Rincian Transaksi per" in joined:
                import re
                match = re.search(r"per\s+(.+?)\s+[–-]\s+(.+?)$", joined.strip())
                if match:
                    from_period = normalize_date_to_str(match.group(1).strip())
                    to_period   = normalize_date_to_str(match.group(2).strip())
                continue

            # Skip header kolom
            if _is_header_row(cells):
                if first_page_header_cells is None:
                    first_page_header_cells = cells
                continue

            # Skip repeat header di halaman lanjutan
            if first_page_header_cells and cells == first_page_header_cells:
                continue

            # Saldo Awal
            if _is_saldo_row(cells, "Saldo Awal"):
                for c in cells:
                    val = normalize_number(c)
                    if val is not None:
                        opening_unit = val
                        break
                continue

            # Saldo Akhir
            if _is_saldo_row(cells, "Saldo Akhir"):
                # Layout: ['', 'Saldo Akhir', nav_date, jumlah_unit, harga_unit, investment_value]
                closing_date   = normalize_date_to_str(cells[2]) if len(cells) > 2 and cells[2] else None
                jumlah_unit_c  = normalize_number(cells[3]) if len(cells) > 3 else None
                harga_unit_c   = normalize_number(cells[4]) if len(cells) > 4 else None
                investment_c   = normalize_number(cells[5]) if len(cells) > 5 else None
                closing = {
                    "nav_date":         closing_date,
                    "jumlah_unit":      jumlah_unit_c,
                    "harga_unit":       harga_unit_c,
                    "investment_value": investment_c,
                }
                found_end = True
                continue

            # Skip baris Lump Sum
            if _is_skip_row(cells):
                continue

            # Deteksi baris nama subdana (hanya 1 cell berisi teks, sisanya None/kosong)
            non_empty_cells = [c for c in cells if c.strip()]
            if len(non_empty_cells) == 1 and not _is_data_row(cells):
                current_fund = non_empty_cells[0].strip()
                continue

            # Baris data valid
            if _is_data_row(cells):
                all_rows_raw.append((cells, current_fund))

        if found_end:
            break

    # Parse baris data
    # Kolom: [0]=Tanggal Transaksi, [1]=Jenis Transaksi, [2]=fund_desc(mungkin kosong),
    #         [3]=Tanggal Harga Unit, [4]=Jumlah Unit, [5]=Harga Unit, [6]=Jumlah Nilai Transaksi
    # Layout bisa bergeser, gunakan deteksi berbasis nilai

    rows = []
    for cells, fund_desc in all_rows_raw:
        # Layout PDF Rincian (6 kolom):
        # [0] Tanggal Transaksi | [1] Jenis Transaksi | [2] Tanggal Harga Unit
        # [3] Jumlah Unit       | [4] Harga Unit       | [5] Jumlah Nilai Transaksi
        import re
        if len(cells) >= 6:
            transaction_date  = normalize_date_to_str(cells[0]) if cells[0] else None
            transaction_code  = cells[1].strip() if len(cells) > 1 else None
            price_date_raw    = cells[2].strip() if len(cells) > 2 else ""
            jumlah_unit_raw   = cells[3].strip() if len(cells) > 3 else ""
            harga_unit_raw    = cells[4].strip() if len(cells) > 4 else ""
            amount_raw        = cells[5].strip() if len(cells) > 5 else ""
        elif len(cells) >= 5:
            transaction_date  = normalize_date_to_str(cells[0]) if cells[0] else None
            transaction_code  = cells[1].strip() if len(cells) > 1 else None
            price_date_raw    = cells[2].strip() if len(cells) > 2 else ""
            jumlah_unit_raw   = cells[3].strip() if len(cells) > 3 else ""
            harga_unit_raw    = ""
            amount_raw        = cells[4].strip() if len(cells) > 4 else ""
        else:
            continue

        rows.append({
            "transaction_date":  transaction_date,
            "transaction_code":  transaction_code,
            "fund_description":  fund_desc,
            "price_date":        normalize_date_to_str(price_date_raw),
            "jumlah_unit":       normalize_number(jumlah_unit_raw),
            "harga_unit":        normalize_number(harga_unit_raw),
            "amount":            normalize_number(amount_raw),
        })

    return {
        "from_period":   from_period,
        "to_period":     to_period,
        "opening_unit":  opening_unit,
        "rows":          rows,
        "closing":       closing,
    }
