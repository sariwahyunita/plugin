import pdfplumber
from .utils import find_anchor_page, normalize_number, normalize_date_to_str


def extract_laporan_transaksi(pdf: pdfplumber.PDF) -> dict:
    """
    Extract tabel Laporan Transaksi (Page 1).
    Anchor: 'Rangkuman Transaksi per'
    Output: {to_period, rows: [{fund_name, nav_date, harga_unit, jumlah_unit, investment_value}], total}
    """
    page_idx = find_anchor_page(pdf, "Rangkuman Transaksi per")
    if page_idx == -1:
        raise ValueError("Anchor 'Rangkuman Transaksi per' tidak ditemukan di PDF")

    page = pdf.pages[page_idx]

    # Extract to_period dari teks anchor
    page_text = page.extract_text() or ""
    to_period = None
    for line in page_text.split("\n"):
        if "Rangkuman Transaksi per" in line:
            to_period = line.replace("Rangkuman Transaksi per", "").strip()
            break

    tables = page.extract_tables()

    # Cari tabel yang mengandung 'Rangkuman Transaksi' atau 'Total Nilai Investasi'
    target_table = None
    for table in tables:
        flat = " ".join(str(cell) for row in table for cell in row if cell)
        if "Total Nilai Investasi" in flat or "Rangkuman Transaksi" in flat:
            target_table = table
            break

    if target_table is None:
        raise ValueError("Tabel Laporan Transaksi tidak ditemukan di PDF")

    rows = []
    total_investment = None
    current_fund = None

    for row in target_table:
        cells = [c.strip() if c else "" for c in row]

        # Skip header rows
        if any(h in cells for h in ["Jenis Subdana", "Tanggal Harga Unit", "Rangkuman Transaksi per"]):
            continue

        # Baris total
        if "Total Nilai Investasi" in cells:
            total_idx = cells.index("Total Nilai Investasi")
            for val in reversed(cells):
                if val and val != "Total Nilai Investasi":
                    total_investment = normalize_number(val)
                    break
            continue

        non_empty = [c for c in cells if c]
        if not non_empty:
            continue

        # Deteksi baris nama subdana (nilai numerik tidak ada di baris ini)
        # Jika hanya ada 1-2 cell berisi teks non-numerik = nama fund lanjutan
        has_numeric = any(
            c.replace(".", "").replace(",", "").replace("-", "").replace("(", "").replace(")", "").isdigit()
            for c in non_empty
        )

        if not has_numeric:
            # Lanjutan nama fund dari baris sebelumnya
            if current_fund is not None:
                current_fund = (current_fund + " " + " ".join(non_empty)).strip()
            else:
                current_fund = " ".join(non_empty).strip()
            continue

        # Baris data: [fund_name_atau_lanjutan, nav_date, harga_unit, jumlah_unit, investment_value]
        # Layout: kolom 0 = fund name (mungkin kosong jika lanjutan), 1 = nav_date, 2 = harga_unit...
        # Ambil berdasarkan posisi kolom (5 kolom)
        if len(cells) >= 5:
            fund_part = cells[0].replace("\n", " ").strip()
            if fund_part:
                current_fund = fund_part
            elif current_fund:
                current_fund = current_fund  # tetap pakai yang sebelumnya
            nav_date_raw    = cells[1].strip() if len(cells) > 1 else ""
            # PDF kolom 2 = Jumlah Unit, kolom 3 = Harga Unit
            jumlah_unit_raw = cells[2].strip() if len(cells) > 2 else ""
            harga_unit_raw  = cells[3].strip() if len(cells) > 3 else ""
            investment_raw  = cells[4].strip() if len(cells) > 4 else ""
        else:
            continue

        rows.append({
            "fund_name":        current_fund,
            "nav_date":         normalize_date_to_str(nav_date_raw),
            "jumlah_unit":      normalize_number(jumlah_unit_raw),
            "harga_unit":       normalize_number(harga_unit_raw),
            "investment_value": normalize_number(investment_raw),
        })

    return {
        "to_period": normalize_date_to_str(to_period),
        "rows":      rows,
        "total":     total_investment,
    }
