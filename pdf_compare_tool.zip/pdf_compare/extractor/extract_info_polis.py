import pdfplumber
from .utils import find_anchor_page, group_words_by_row, row_to_text

# Label-label yang diketahui ada di info polis, berurutan dari atas ke bawah.
# "Nama Financial Advisor" adalah label TERAKHIR — digunakan sebagai batas bawah.
KNOWN_LABELS = [
    "No. Polis",
    "Tertanggung",
    "Jumlah Premi Top Up Tunggal",
    "Status Polis",
    "Tanggal Mulai Asuransi",
    "Nama Produk",
    "Uang Pertanggungan",
    "Tanggal Cetak Laporan",
    "Nama Financial Advisor",
]

LAST_LABEL = "Nama Financial Advisor"


def extract_info_polis(pdf: pdfplumber.PDF) -> dict:
    """
    Extract informasi polis dari area kanan Page 1.
    Pola: label [x~245] → ':' [x~393] → nilai [x~409]
    Batas bawah: baris label terakhir ('Nama Financial Advisor') + toleransi.
    Output: {policy_no, insured_name, lump_sum_premium, status_code,
             policy_date, plan_description, up, print_date, agent_name}
    """
    page_idx = find_anchor_page(pdf, "No. Polis")
    if page_idx == -1:
        raise ValueError("Anchor 'No. Polis' tidak ditemukan di PDF")

    page = pdf.pages[page_idx]
    words = page.extract_words(x_tolerance=3, y_tolerance=3)

    # Temukan posisi y "No. Polis" sebagai batas atas
    anchor_y = None
    for w in words:
        if w["text"] == "No." and any(
            w2["text"] == "Polis" and abs(w2["top"] - w["top"]) < 3
            for w2 in words
        ):
            anchor_y = w["top"]
            break

    if anchor_y is None:
        raise ValueError("Posisi 'No. Polis' tidak ditemukan")

    # Temukan posisi y label TERAKHIR ("Nama Financial Advisor") sebagai batas bawah
    last_label_y = None
    for w in words:
        if w["text"] == "Nama" and w["x0"] >= 230:
            # Cek apakah baris ini mengandung "Financial" dan "Advisor"
            same_row = [
                w2["text"] for w2 in words
                if abs(w2["top"] - w["top"]) < 3 and w2["x0"] >= 230
            ]
            if "Financial" in same_row and "Advisor" in same_row:
                last_label_y = w["top"]
                break

    if last_label_y is None:
        # Fallback: gunakan batas y relatif dari anchor (9 baris * ~12pt per baris)
        last_label_y = anchor_y + 120

    # Batas bawah = y label terakhir + toleransi satu baris (~15pt)
    y_bottom = last_label_y + 15

    # Ambil kata-kata di area kanan (x0 >= 230), antara anchor_y dan y_bottom
    right_words = [
        w for w in words
        if w["x0"] >= 230
        and w["top"] >= anchor_y - 2
        and w["top"] <= y_bottom
    ]

    rows = group_words_by_row(right_words, tolerance=3.0)

    # Parse setiap baris: ambil nilai setelah ':'
    parsed = {}
    pending_label = None

    for row in rows:
        texts = [w["text"] for w in row]

        if ":" in texts:
            colon_idx = texts.index(":")
            label_parts = texts[:colon_idx]
            value_parts = texts[colon_idx + 1:]
            label = " ".join(label_parts).strip()
            value = " ".join(value_parts).strip()
            parsed[label] = value
            pending_label = label
        else:
            # Baris lanjutan (misal: 'Sejahtera' lanjutan 'Nama Produk')
            # Tambahkan spasi sebelum menggabungkan
            if pending_label and row:
                existing = parsed.get(pending_label, "").rstrip()
                continuation = row_to_text(row).strip()
                parsed[pending_label] = existing + " " + continuation

    def get(key):
        return parsed.get(key, "").strip() or None

    return {
        "policy_no":          get("No. Polis"),
        "insured_name":       get("Tertanggung"),
        "lump_sum_premium":   get("Jumlah Premi Top Up Tunggal"),
        "status_code":        get("Status Polis"),
        "policy_date":        get("Tanggal Mulai Asuransi"),
        "plan_description":   get("Nama Produk"),
        "up":                 get("Uang Pertanggungan"),
        "print_date":         get("Tanggal Cetak Laporan"),
        "agent_name":         get("Nama Financial Advisor"),
    }
