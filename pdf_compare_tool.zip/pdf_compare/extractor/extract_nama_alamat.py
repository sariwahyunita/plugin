import pdfplumber
from .utils import find_anchor_page, group_words_by_row, row_to_text


def extract_nama_alamat(pdf: pdfplumber.PDF) -> dict:
    """
    Extract nama penerima dan alamat dari area kiri halaman (Page 1).
    Anchor: 'Kepada Yth.'
    Output: {owner, address_1, address_2, address_3, address_4}
    """
    page_idx = find_anchor_page(pdf, "Kepada Yth.")
    if page_idx == -1:
        raise ValueError("Anchor 'Kepada Yth.' tidak ditemukan di PDF")

    page = pdf.pages[page_idx]
    words = page.extract_words(x_tolerance=3, y_tolerance=3)

    # Temukan posisi y anchor 'Kepada Yth.'
    anchor_y = None
    for w in words:
        if w["text"] == "Kepada":
            anchor_y = w["top"]
            break

    if anchor_y is None:
        raise ValueError("Kata 'Kepada' tidak ditemukan di halaman PDF")

    # Ambil semua kata di area kiri (x0 < 230) dan di bawah anchor
    left_words = [
        w for w in words
        if w["x0"] < 230 and w["top"] > anchor_y
    ]

    rows = group_words_by_row(left_words, tolerance=3.0)

    # Baris pertama setelah anchor = nama (IBU RUSININI)
    # Baris berikutnya = address_1, _2, _3, _4
    address_lines = []
    for row in rows:
        text = row_to_text(row).strip()
        if text:
            address_lines.append(text)

    def get_line(idx):
        return address_lines[idx] if idx < len(address_lines) else None

    return {
        "owner":     get_line(0),
        "address_1": get_line(1),
        "address_2": get_line(2),
        "address_3": get_line(3),
        "address_4": get_line(4),
    }
