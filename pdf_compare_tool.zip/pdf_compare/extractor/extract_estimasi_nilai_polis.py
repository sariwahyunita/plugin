import pdfplumber
from .utils import find_anchor_page, normalize_number


def extract_estimasi_nilai_polis(pdf: pdfplumber.PDF) -> dict:
    """
    Extract tabel Estimasi Nilai Polis (Page 1).
    Anchor: 'Estimasi Nilai Polis'
    Output: {rows: [{fund_name, investment_value, surrender_pct, surrender_amount, net_amount}], total}
    """
    page_idx = find_anchor_page(pdf, "Estimasi Nilai Polis")
    if page_idx == -1:
        raise ValueError("Anchor 'Estimasi Nilai Polis' tidak ditemukan di PDF")

    page = pdf.pages[page_idx]
    tables = page.extract_tables()

    # Cari tabel yang mengandung 'Total Nilai Penarikan'
    target_table = None
    for table in tables:
        flat = " ".join(str(cell) for row in table for cell in row if cell)
        if "Total Nilai Penarikan" in flat or "Nilai Penarikan/Penutupan" in flat:
            target_table = table
            break

    if target_table is None:
        raise ValueError("Tabel Estimasi Nilai Polis tidak ditemukan di PDF")

    rows = []
    total_net = None
    current_fund = None

    # Kolom: Jenis Subdana | Nilai Investasi | Biaya % | Biaya Rupiah | Nilai Penarikan
    for row in target_table:
        cells = [c.replace("\n", " ").strip() if c else "" for c in row]
        non_empty = [c for c in cells if c]

        if not non_empty:
            continue

        # Skip header
        if any(h in " ".join(cells) for h in ["Jenis Subdana", "Nilai Investasi (Rupiah)", "Biaya Penarikan"]):
            continue

        # Baris total
        if "Total Nilai Penarikan" in " ".join(cells):
            for val in reversed(cells):
                if val and "Total" not in val:
                    total_net = normalize_number(val)
                    break
            continue

        has_numeric = any(
            c.replace(".", "").replace(",", "").replace("-", "").replace("(", "").replace(")", "").isdigit()
            for c in non_empty
        )

        if not has_numeric:
            if current_fund:
                current_fund = (current_fund + " " + " ".join(non_empty)).strip()
            else:
                current_fund = " ".join(non_empty).strip()
            continue

        if len(cells) >= 5:
            fund_part = cells[0].strip()
            if fund_part:
                current_fund = fund_part
            investment_raw   = cells[1].strip() if len(cells) > 1 else ""
            surrender_pct_raw = cells[2].strip() if len(cells) > 2 else ""
            surrender_amt_raw = cells[3].strip() if len(cells) > 3 else ""
            net_amount_raw    = cells[4].strip() if len(cells) > 4 else ""
        else:
            continue

        rows.append({
            "fund_name":        current_fund,
            "investment_value": normalize_number(investment_raw),
            "surrender_pct":    normalize_number(surrender_pct_raw),
            "surrender_amount": normalize_number(surrender_amt_raw),
            "net_amount":       normalize_number(net_amount_raw),
        })

    return {
        "rows":  rows,
        "total": total_net,
    }
