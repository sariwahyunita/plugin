import pandas as pd
from extractor.utils import normalize_date_to_str, round4, round2


def read_excel_data(excel_path: str) -> dict:
    """
    Baca semua sheet dari file Excel DB dan return sebagai dict terstruktur.
    Formula string (=D2*E2) akan dikalkulasi ulang secara manual.
    """
    sheets = pd.read_excel(excel_path, sheet_name=None, dtype=str)

    def get_sheet(name):
        for k in sheets:
            if k.strip().lower() == name.strip().lower():
                return sheets[k]
        return None

    # ── DATA PENERIMA ──────────────────────────────────────────────
    df_penerima = get_sheet("DATA PENERIMA")
    if df_penerima is None:
        raise ValueError("Sheet 'DATA PENERIMA' tidak ditemukan di Excel")

    row_p = df_penerima.iloc[0]

    def val(r, col):
        v = r.get(col, None)
        return str(v).strip() if pd.notna(v) and str(v).strip() not in ("", "nan") else None

    penerima = {
        "owner":              val(row_p, "owner"),
        "corr_address_1":     val(row_p, "corr_address_1"),
        "corr_address_2":     val(row_p, "corr_address_2"),
        "corr_address_3":     val(row_p, "corr_address_3"),
        "corr_address_4":     val(row_p, "corr_address_4"),
        "policy_no":          val(row_p, "policy_no"),
        "insured_name":       val(row_p, "insured_name"),
        "lump_sum_premium":   val(row_p, "lump_sum_premium"),
        "status_code":        val(row_p, "status_code"),
        "policy_date":        normalize_date_to_str(val(row_p, "policy_date")),
        "plan_description":   val(row_p, "plan_description"),
        "up":                 val(row_p, "up"),
        "print_date":         normalize_date_to_str(val(row_p, "print_date")),
        "agent_name":         val(row_p, "agent_name"),
    }

    # ── LAPORAN TRANSAKSI ──────────────────────────────────────────
    df_lap = get_sheet("Laporan Transaksi")
    if df_lap is None:
        raise ValueError("Sheet 'Laporan Transaksi' tidak ditemukan di Excel")

    lap_rows = []
    for _, r in df_lap.iterrows():
        # Mapping dikonfirmasi:
        # jumlah_unit = closing_unit (427.1266), harga_unit = bid_price (933.2868)
        jumlah_unit = _to_float(val(r, "closing_unit"))
        harga_unit  = _to_float(val(r, "bid_price"))
        # investment_value: gunakan kolom investment_value (sudah terhitung di DB), round2
        inv_val = round2(_to_float(val(r, "investment_value")))

        lap_rows.append({
            "fund_name":        val(r, "u_l_fund_description"),
            "nav_date":         normalize_date_to_str(val(r, "TSNAV")),
            "jumlah_unit":      jumlah_unit,   # no rounding — compare di layer comparator
            "harga_unit":       harga_unit,    # no rounding — compare di layer comparator
            "investment_value": inv_val,
        })

    lap_total = sum(
        r["investment_value"] for r in lap_rows if r["investment_value"] is not None
    )

    to_period = normalize_date_to_str(val(df_lap.iloc[0], "to_period")) if len(df_lap) > 0 else None

    laporan = {
        "to_period": to_period,
        "rows":      lap_rows,
        "total":     round2(lap_total),
    }

    # ── ESTIMASI BIAYA ─────────────────────────────────────────────
    df_est = get_sheet("Informasi estimasi biaya")
    if df_est is None:
        raise ValueError("Sheet 'Informasi estimasi biaya' tidak ditemukan di Excel")

    est_rows = []
    for _, r in df_est.iterrows():
        inv_val      = _to_float(val(r, "investment_value"))
        surr_pct     = _to_float(val(r, "surrender_percentage"))
        surr_amt     = _to_float(val(r, "surrender_amount"))
        net_amt      = _to_float(val(r, "net_amount"))
        est_rows.append({
            "fund_name":        val(r, "u_l_fund_description"),
            "investment_value": round4(inv_val),
            "surrender_pct":    round4(surr_pct),
            "surrender_amount": round4(surr_amt),
            "net_amount":       round4(net_amt),
        })

    est_total = sum(r["net_amount"] for r in est_rows if r["net_amount"] is not None)

    estimasi = {
        "rows":  est_rows,
        "total": round4(est_total),
    }

    # ── RINCIAN LAPORAN TRANSAKSI ──────────────────────────────────
    df_rin = get_sheet("RINCIAN LAPORAN TRANSAKSI")
    if df_rin is None:
        raise ValueError("Sheet 'RINCIAN LAPORAN TRANSAKSI' tidak ditemukan di Excel")

    rin_rows = []
    for _, r in df_rin.iterrows():
        txn_unit   = _to_float(val(r, "transaction_in_unit"))
        unit_price = _to_float(val(r, "unit_price"))
        # amount: gunakan kolom transaction_amount_in_fund_ccy (sudah terhitung di DB), round2
        amount = round2(_to_float(val(r, "transaction_amount_in_fund_ccy")))

        rin_rows.append({
            "transaction_date": normalize_date_to_str(val(r, "transaction_date")),
            "transaction_code": val(r, "transaction_code"),
            "fund_description": val(r, "u_l_fund_description"),
            "price_date":       normalize_date_to_str(val(r, "u_l_fund_price_date")),
            "jumlah_unit":      txn_unit,   # no pre-rounding
            "harga_unit":       unit_price, # no pre-rounding
            "amount":           amount,
        })

    # Opening dari baris pertama
    row_first    = df_rin.iloc[0] if len(df_rin) > 0 else None
    opening_unit = _to_float(val(row_first, "opening_unit")) if row_first is not None else None

    # Closing (Saldo Akhir): jumlah_unit=closing_unit, harga_unit=bid_price
    row_last       = df_rin.iloc[-1] if len(df_rin) > 0 else None
    closing_jumlah = _to_float(val(row_last, "closing_unit")) if row_last is not None else None
    closing_harga  = _to_float(val(row_last, "bid_price"))    if row_last is not None else None
    closing_inv    = round2(closing_jumlah * closing_harga) if (closing_jumlah and closing_harga) else None

    from_period = normalize_date_to_str(val(df_rin.iloc[0], "from_period - to_period")) if len(df_rin) > 0 else None
    to_period_r = normalize_date_to_str(val(df_rin.iloc[0], "to_period"))   if len(df_rin) > 0 else None

    rincian = {
        "from_period":  from_period,
        "to_period":    to_period_r,
        "opening_unit": round2(opening_unit),
        "rows":         rin_rows,
        "closing": {
            "jumlah_unit":      closing_jumlah,
            "harga_unit":       closing_harga,
            "investment_value": closing_inv,
        },
    }

    # ── INFORMASI JATUH TEMPO ──────────────────────────────────────
    df_jt = get_sheet("Informasi Jatuh Tempo")
    if df_jt is None:
        raise ValueError("Sheet 'Informasi Jatuh Tempo' tidak ditemukan di Excel")

    row_jt = df_jt.iloc[0]
    jatuh_tempo = {
        "basic_premi":    _to_float(val(row_jt, "basic_premi")),
        "rider":          _to_float(val(row_jt, "rider")),
        "top_up":         _to_float(val(row_jt, "top_up")),
        "extra_premi":    _to_float(val(row_jt, "extra_premi")),
        "total_premi":    _to_float(val(row_jt, "total_premi")),
        "due_date":       val(row_jt, "paid-to-date"),
        "payment_mode":   val(row_jt, "payment_mode"),
        "account_number": val(row_jt, "payment_method_account_number"),
    }

    return {
        "penerima":    penerima,
        "laporan":     laporan,
        "estimasi":    estimasi,
        "rincian":     rincian,
        "jatuh_tempo": jatuh_tempo,
    }


def _to_float(value):
    if value is None:
        return None
    try:
        return float(str(value).replace(",", ".").strip())
    except (ValueError, TypeError):
        return None
