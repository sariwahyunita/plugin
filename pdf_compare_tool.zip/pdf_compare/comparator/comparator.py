from extractor.utils import round4, round2, normalize_number

PASS = "PASS"
FAIL = "FAIL"
ERROR = "ERROR"


def _compare_field(section, field, pdf_val, excel_val, is_numeric=False, decimals=4):
    """
    Buat 1 baris hasil compare.
    decimals: jumlah angka di belakang koma untuk compare numerik (default 4, bisa 2)
    Return dict: {section, field, nilai_pdf, nilai_excel, status, remark}
    """
    rounder = round2 if decimals == 2 else round4
    try:
        if is_numeric:
            pdf_f   = rounder(normalize_number(str(pdf_val))) if isinstance(pdf_val, str) else rounder(pdf_val)
            excel_f = rounder(excel_val)
            status  = PASS if pdf_f == excel_f else FAIL
            remark  = "" if status == PASS else f"PDF={pdf_f} | Excel={excel_f}"
            return {
                "section":     section,
                "field":       field,
                "nilai_pdf":   pdf_f,
                "nilai_excel": excel_f,
                "status":      status,
                "remark":      remark,
            }
        else:
            pdf_s   = str(pdf_val).strip() if pdf_val is not None else ""
            excel_s = str(excel_val).strip() if excel_val is not None else ""
            status  = PASS if pdf_s == excel_s else FAIL
            remark  = "" if status == PASS else f"PDF={pdf_s} | Excel={excel_s}"
            return {
                "section":     section,
                "field":       field,
                "nilai_pdf":   pdf_s,
                "nilai_excel": excel_s,
                "status":      status,
                "remark":      remark,
            }
    except Exception as e:
        return {
            "section":     section,
            "field":       field,
            "nilai_pdf":   str(pdf_val),
            "nilai_excel": str(excel_val),
            "status":      ERROR,
            "remark":      str(e),
        }


def _section_header(section_name):
    return {
        "section":     section_name,
        "field":       "",
        "nilai_pdf":   "",
        "nilai_excel": "",
        "status":      "",
        "remark":      "",
    }


# ── SECTION 1: NAMA & ALAMAT ───────────────────────────────────────────────────

def compare_nama_alamat(pdf_data: dict, excel_data: dict) -> list:
    S = "NAMA & ALAMAT"
    ex = excel_data["penerima"]
    pd_ = pdf_data

    results = [_section_header(S)]
    results.append(_compare_field(S, "owner",     pd_.get("owner"),     ex.get("owner")))
    results.append(_compare_field(S, "address_1", pd_.get("address_1"), ex.get("corr_address_1")))
    results.append(_compare_field(S, "address_2", pd_.get("address_2"), ex.get("corr_address_2")))
    results.append(_compare_field(S, "address_3", pd_.get("address_3"), ex.get("corr_address_3")))
    results.append(_compare_field(S, "address_4", pd_.get("address_4"), ex.get("corr_address_4")))
    return results


# ── SECTION 2: INFORMASI POLIS ─────────────────────────────────────────────────

def compare_info_polis(pdf_data: dict, excel_data: dict) -> list:
    S = "INFORMASI POLIS"
    ex = excel_data["penerima"]
    pd_ = pdf_data

    results = [_section_header(S)]
    results.append(_compare_field(S, "policy_no",        pd_.get("policy_no"),        ex.get("policy_no")))
    results.append(_compare_field(S, "insured_name",     pd_.get("insured_name"),     ex.get("insured_name")))
    results.append(_compare_field(S, "lump_sum_premium", pd_.get("lump_sum_premium"), ex.get("lump_sum_premium"), is_numeric=True))
    results.append(_compare_field(S, "status_code",      pd_.get("status_code"),      ex.get("status_code")))
    results.append(_compare_field(S, "policy_date",      pd_.get("policy_date"),      ex.get("policy_date")))
    results.append(_compare_field(S, "plan_description", pd_.get("plan_description"), ex.get("plan_description")))
    results.append(_compare_field(S, "up",               pd_.get("up"),               ex.get("up"), is_numeric=True))
    results.append(_compare_field(S, "print_date",       pd_.get("print_date"),       ex.get("print_date")))
    results.append(_compare_field(S, "agent_name",       pd_.get("agent_name"),       ex.get("agent_name")))
    return results


# ── SECTION 3: LAPORAN TRANSAKSI ───────────────────────────────────────────────

def compare_laporan_transaksi(pdf_data: dict, excel_data: dict) -> list:
    S = "LAPORAN TRANSAKSI"
    ex = excel_data["laporan"]
    pd_ = pdf_data

    results = [_section_header(S)]

    # Header: to_period
    results.append(_compare_field(S, "to_period", pd_.get("to_period"), ex.get("to_period")))

    pdf_rows   = pd_.get("rows", [])
    excel_rows = ex.get("rows", [])

    # Validasi jumlah baris
    if len(pdf_rows) != len(excel_rows):
        results.append({
            "section":     S,
            "field":       "row_count",
            "nilai_pdf":   len(pdf_rows),
            "nilai_excel": len(excel_rows),
            "status":      FAIL,
            "remark":      f"Jumlah baris berbeda: PDF={len(pdf_rows)} | Excel={len(excel_rows)}",
        })

    for i, (pr, er) in enumerate(zip(pdf_rows, excel_rows), 1):
        prefix = f"row_{i}"
        results.append(_compare_field(S, f"{prefix} | fund_name",        pr.get("fund_name"),        er.get("fund_name")))
        results.append(_compare_field(S, f"{prefix} | nav_date",         pr.get("nav_date"),         er.get("nav_date")))
        results.append(_compare_field(S, f"{prefix} | harga_unit",       pr.get("harga_unit"),       er.get("harga_unit"),       is_numeric=True, decimals=2))
        results.append(_compare_field(S, f"{prefix} | jumlah_unit",      pr.get("jumlah_unit"),      er.get("jumlah_unit"),      is_numeric=True, decimals=2))
        results.append(_compare_field(S, f"{prefix} | investment_value", pr.get("investment_value"), er.get("investment_value"), is_numeric=True, decimals=2))

    results.append(_compare_field(S, "total_investment", pd_.get("total"), ex.get("total"), is_numeric=True, decimals=2))
    return results


# ── SECTION 4: ESTIMASI NILAI POLIS ───────────────────────────────────────────

def compare_estimasi_nilai_polis(pdf_data: dict, excel_data: dict) -> list:
    S = "ESTIMASI NILAI POLIS"
    ex = excel_data["estimasi"]
    pd_ = pdf_data

    results = [_section_header(S)]

    pdf_rows   = pd_.get("rows", [])
    excel_rows = ex.get("rows", [])

    if len(pdf_rows) != len(excel_rows):
        results.append({
            "section":     S,
            "field":       "row_count",
            "nilai_pdf":   len(pdf_rows),
            "nilai_excel": len(excel_rows),
            "status":      FAIL,
            "remark":      f"Jumlah baris berbeda: PDF={len(pdf_rows)} | Excel={len(excel_rows)}",
        })

    for i, (pr, er) in enumerate(zip(pdf_rows, excel_rows), 1):
        prefix = f"row_{i}"
        results.append(_compare_field(S, f"{prefix} | fund_name",        pr.get("fund_name"),        er.get("fund_name")))
        results.append(_compare_field(S, f"{prefix} | investment_value", pr.get("investment_value"), er.get("investment_value"), is_numeric=True))
        results.append(_compare_field(S, f"{prefix} | surrender_pct",    pr.get("surrender_pct"),    er.get("surrender_pct"),    is_numeric=True))
        results.append(_compare_field(S, f"{prefix} | surrender_amount", pr.get("surrender_amount"), er.get("surrender_amount"), is_numeric=True))
        results.append(_compare_field(S, f"{prefix} | net_amount",       pr.get("net_amount"),       er.get("net_amount"),       is_numeric=True))

    results.append(_compare_field(S, "total_net", pd_.get("total"), ex.get("total"), is_numeric=True))
    return results


# ── SECTION 5: RINCIAN LAPORAN TRANSAKSI ──────────────────────────────────────

def compare_rincian_transaksi(pdf_data: dict, excel_data: dict) -> list:
    S = "RINCIAN LAPORAN TRANSAKSI"
    ex = excel_data["rincian"]
    pd_ = pdf_data

    results = [_section_header(S)]

    # Header periode
    results.append(_compare_field(S, "from_period",  pd_.get("from_period"),  ex.get("from_period")))
    results.append(_compare_field(S, "to_period",    pd_.get("to_period"),    ex.get("to_period")))
    results.append(_compare_field(S, "opening_unit", pd_.get("opening_unit"), ex.get("opening_unit"), is_numeric=True))

    pdf_rows   = pd_.get("rows", [])
    excel_rows = ex.get("rows", [])

    # Validasi jumlah baris
    if len(pdf_rows) != len(excel_rows):
        results.append({
            "section":     S,
            "field":       "row_count",
            "nilai_pdf":   len(pdf_rows),
            "nilai_excel": len(excel_rows),
            "status":      FAIL,
            "remark":      f"Jumlah baris berbeda: PDF={len(pdf_rows)} | Excel={len(excel_rows)} — tetap lanjut compare",
        })

    # Composite key matching: transaction_date + transaction_code + fund_description
    def make_key(row):
        return (
            str(row.get("transaction_date") or ""),
            str(row.get("transaction_code") or ""),
            str(row.get("fund_description") or ""),
        )

    # Build Excel lookup: key -> list of rows (untuk handle duplikat dengan tiebreaker urutan)
    excel_lookup = {}
    for idx, er in enumerate(excel_rows):
        key = make_key(er)
        if key not in excel_lookup:
            excel_lookup[key] = []
        excel_lookup[key].append((idx, er))

    matched_excel_indices = set()

    for pr in pdf_rows:
        key = make_key(pr)
        field_prefix = f"{key[0]} | {key[1]}"

        candidates = excel_lookup.get(key, [])
        # Tiebreaker: ambil kandidat yang belum dipakai, urutan pertama
        er = None
        for idx, candidate in candidates:
            if idx not in matched_excel_indices:
                er = candidate
                matched_excel_indices.add(idx)
                break

        if er is None:
            results.append({
                "section":     S,
                "field":       f"{field_prefix} | [NOT FOUND IN EXCEL]",
                "nilai_pdf":   str(key),
                "nilai_excel": "-",
                "status":      FAIL,
                "remark":      "Baris tidak ditemukan di Excel berdasarkan composite key",
            })
            continue

        results.append(_compare_field(S, f"{field_prefix} | price_date",   pr.get("price_date"),  er.get("price_date")))
        results.append(_compare_field(S, f"{field_prefix} | jumlah_unit",  pr.get("jumlah_unit"), er.get("jumlah_unit"), is_numeric=True, decimals=2))
        results.append(_compare_field(S, f"{field_prefix} | harga_unit",   pr.get("harga_unit"),  er.get("harga_unit"),  is_numeric=True, decimals=2))
        results.append(_compare_field(S, f"{field_prefix} | amount",       pr.get("amount"),      er.get("amount"),      is_numeric=True, decimals=2))

    # Closing / Saldo Akhir
    pdf_closing   = pd_.get("closing") or {}
    excel_closing = ex.get("closing") or {}
    results.append(_compare_field(S, "saldo_akhir | jumlah_unit",      pdf_closing.get("jumlah_unit"),      excel_closing.get("jumlah_unit"),      is_numeric=True, decimals=2))
    results.append(_compare_field(S, "saldo_akhir | harga_unit",       pdf_closing.get("harga_unit"),       excel_closing.get("harga_unit"),       is_numeric=True, decimals=2))
    results.append(_compare_field(S, "saldo_akhir | investment_value", pdf_closing.get("investment_value"), excel_closing.get("investment_value"), is_numeric=True, decimals=2))

    return results


# ── SECTION 6: INFORMASI JATUH TEMPO ──────────────────────────────────────────

def compare_jatuh_tempo(pdf_data: dict, excel_data: dict) -> list:
    S = "INFORMASI JATUH TEMPO"
    ex = excel_data["jatuh_tempo"]
    pd_ = pdf_data

    results = [_section_header(S)]
    results.append(_compare_field(S, "basic_premi",    pd_.get("basic_premi"),    ex.get("basic_premi"),    is_numeric=True))
    results.append(_compare_field(S, "rider",          pd_.get("rider"),          ex.get("rider"),          is_numeric=True))
    results.append(_compare_field(S, "top_up",         pd_.get("top_up"),         ex.get("top_up"),         is_numeric=True))
    results.append(_compare_field(S, "extra_premi",    pd_.get("extra_premi"),    ex.get("extra_premi"),    is_numeric=True))
    results.append(_compare_field(S, "total_premi",    pd_.get("total_premi"),    ex.get("total_premi"),    is_numeric=True))
    results.append(_compare_field(S, "due_date",       pd_.get("due_date"),       ex.get("due_date")))
    results.append(_compare_field(S, "payment_mode",   pd_.get("payment_mode"),   ex.get("payment_mode")))
    results.append(_compare_field(S, "account_number", pd_.get("account_number"), ex.get("account_number")))
    return results
