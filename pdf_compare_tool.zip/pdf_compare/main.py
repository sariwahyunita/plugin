"""
PDF Compare Tool — Main Orchestrator
=====================================
Usage:
    python main.py

Folder structure:
    resource/data/pdf/          → laporan_{policy_no}.pdf
    resource/data/excel/        → data_{policy_no}.xlsx
    resource/data/testcase/     → testcase.xlsx
    results/{datetime}/         → testcase_summary.xlsx
    results/{datetime}/detail/  → {policy_no}_compare.xlsx
"""

import os
import sys
import pdfplumber
import pandas as pd
from datetime import datetime

# Tambahkan root ke path agar import module berjalan
sys.path.insert(0, os.path.dirname(__file__))

from extractor import (
    extract_nama_alamat,
    extract_info_polis,
    extract_laporan_transaksi,
    extract_estimasi_nilai_polis,
    extract_rincian_transaksi,
    extract_jatuh_tempo,
)
from comparator import (
    compare_nama_alamat,
    compare_info_polis,
    compare_laporan_transaksi,
    compare_estimasi_nilai_polis,
    compare_rincian_transaksi,
    compare_jatuh_tempo,
    read_excel_data,
)
from reporter import write_detail_report, write_summary_report

# ── PATH CONFIG ────────────────────────────────────────────────────────────────
BASE_DIR      = os.path.dirname(__file__)
DIR_PDF       = os.path.join(BASE_DIR, "resource", "data", "pdf")
DIR_EXCEL     = os.path.join(BASE_DIR, "resource", "data", "excel")
DIR_TESTCASE  = os.path.join(BASE_DIR, "resource", "data", "testcase")
DIR_RESULTS   = os.path.join(BASE_DIR, "results")

TESTCASE_FILE = os.path.join(DIR_TESTCASE, "testcase.xlsx")


def get_result_dirs() -> tuple:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    result_root   = os.path.join(DIR_RESULTS, ts)
    result_detail = os.path.join(result_root, "detail")
    os.makedirs(result_detail, exist_ok=True)
    return result_root, result_detail


def load_testcases() -> list:
    df = pd.read_excel(TESTCASE_FILE, dtype=str)
    df.columns = [c.strip().lower() for c in df.columns]
    return df.to_dict("records")


def run_compare_for_policy(policy_no: str, product_code: str) -> dict:
    """
    Jalankan full compare untuk 1 polis.
    Return: {results, pass, fail, error, executed}
    """
    pdf_path   = os.path.join(DIR_PDF,   f"laporan_{policy_no}.pdf")
    excel_path = os.path.join(DIR_EXCEL, f"data_{policy_no}.xlsx")

    # Cek ketersediaan file
    if not os.path.exists(pdf_path):
        raise FileNotFoundError(f"File PDF tidak ditemukan: laporan_{policy_no}.pdf")
    if not os.path.exists(excel_path):
        raise FileNotFoundError(f"File Excel tidak ditemukan: data_{policy_no}.xlsx")

    all_results = []

    # ── Baca Excel DB ──────────────────────────────────────────────
    excel_data = read_excel_data(excel_path)

    with pdfplumber.open(pdf_path) as pdf:

        # ── PAGE 1: Nama & Alamat ──────────────────────────────────
        try:
            pdf_nama = extract_nama_alamat(pdf)
            all_results += compare_nama_alamat(pdf_nama, excel_data)
        except Exception as e:
            all_results += _error_section("NAMA & ALAMAT", str(e))

        # ── PAGE 1: Informasi Polis ────────────────────────────────
        try:
            pdf_polis = extract_info_polis(pdf)
            all_results += compare_info_polis(pdf_polis, excel_data)
        except Exception as e:
            all_results += _error_section("INFORMASI POLIS", str(e))

        # ── PAGE 1: Laporan Transaksi ──────────────────────────────
        try:
            pdf_lap = extract_laporan_transaksi(pdf)
            all_results += compare_laporan_transaksi(pdf_lap, excel_data)
        except Exception as e:
            all_results += _error_section("LAPORAN TRANSAKSI", str(e))

        # ── PAGE 1: Estimasi Nilai Polis ───────────────────────────
        try:
            pdf_est = extract_estimasi_nilai_polis(pdf)
            all_results += compare_estimasi_nilai_polis(pdf_est, excel_data)
        except Exception as e:
            all_results += _error_section("ESTIMASI NILAI POLIS", str(e))

        # ── PAGE 2: Rincian Laporan Transaksi ─────────────────────
        try:
            pdf_rin = extract_rincian_transaksi(pdf)
            all_results += compare_rincian_transaksi(pdf_rin, excel_data)
        except Exception as e:
            all_results += _error_section("RINCIAN LAPORAN TRANSAKSI", str(e))

        # ── PAGE 2: Informasi Jatuh Tempo ─────────────────────────
        try:
            pdf_jt = extract_jatuh_tempo(pdf)
            all_results += compare_jatuh_tempo(pdf_jt, excel_data)
        except Exception as e:
            all_results += _error_section("INFORMASI JATUH TEMPO", str(e))

    # Hitung statistik (exclude section header rows)
    data_rows = [r for r in all_results if r.get("field")]
    n_pass    = sum(1 for r in data_rows if r["status"] == "PASS")
    n_fail    = sum(1 for r in data_rows if r["status"] == "FAIL")
    n_error   = sum(1 for r in data_rows if r["status"] == "ERROR")
    n_exec    = len(data_rows)

    return {
        "results":  all_results,
        "executed": n_exec,
        "pass":     n_pass,
        "fail":     n_fail,
        "error":    n_error,
    }


def _error_section(section_name: str, message: str) -> list:
    """Return error rows untuk section yang gagal di-extract."""
    return [
        {"section": section_name, "field": "", "nilai_pdf": "", "nilai_excel": "", "status": "", "remark": ""},
        {"section": section_name, "field": "EXTRACT ERROR", "nilai_pdf": "-", "nilai_excel": "-",
         "status": "ERROR", "remark": message},
    ]


def main():
    print("=" * 60)
    print("PDF Compare Tool")
    print("=" * 60)

    testcases = load_testcases()
    result_root, result_detail = get_result_dirs()
    summary_path = os.path.join(result_root, "testcase_summary.xlsx")

    summary_rows = []

    for tc in testcases:
        tc_id        = tc.get("test_case_id", "")
        policy_no    = tc.get("policy_number", "")
        product_code = tc.get("product_code", "")
        skip_flag    = str(tc.get("skip", "N")).strip().upper()

        print(f"\n[{tc_id}] Policy: {policy_no} | Skip: {skip_flag}")

        # ── SKIP ──────────────────────────────────────────────────
        if skip_flag == "Y":
            print(f"  → SKIP")
            summary_rows.append({
                "test_case_id": tc_id,
                "policy_number": policy_no,
                "product_code":  product_code,
                "skip":          "Y",
                "status":        "SKIP",
                "executed":      0,
                "pass":          0,
                "fail":          0,
                "error":         0,
                "skip_count":    1,
                "remark":        "Di-skip manual via kolom skip=Y",
            })
            continue

        # ── EXECUTE ───────────────────────────────────────────────
        try:
            result = run_compare_for_policy(policy_no, product_code)

            detail_path = os.path.join(result_detail, f"{policy_no}_compare.xlsx")
            write_detail_report(result["results"], detail_path, policy_no)

            overall_status = "PASS" if result["fail"] == 0 and result["error"] == 0 else "FAIL"

            print(f"  → {overall_status} | Execute={result['executed']} "
                  f"Pass={result['pass']} Fail={result['fail']} Error={result['error']}")

            summary_rows.append({
                "test_case_id": tc_id,
                "policy_number": policy_no,
                "product_code":  product_code,
                "skip":          "N",
                "status":        overall_status,
                "executed":      result["executed"],
                "pass":          result["pass"],
                "fail":          result["fail"],
                "error":         result["error"],
                "skip_count":    0,
                "remark":        f"Detail: {policy_no}_compare.xlsx",
            })

        except Exception as e:
            print(f"  → ERROR: {e}")
            summary_rows.append({
                "test_case_id": tc_id,
                "policy_number": policy_no,
                "product_code":  product_code,
                "skip":          "N",
                "status":        "ERROR",
                "executed":      0,
                "pass":          0,
                "fail":          0,
                "error":         1,
                "skip_count":    0,
                "remark":        str(e),
            })

    # Tulis summary
    write_summary_report(summary_rows, summary_path)

    print(f"\n{'=' * 60}")
    print(f"Selesai. Output tersimpan di: results/{os.path.basename(result_root)}/")
    print(f"  Summary : testcase_summary.xlsx")
    print(f"  Detail  : detail/{{policy_no}}_compare.xlsx")
    print("=" * 60)


if __name__ == "__main__":
    main()
