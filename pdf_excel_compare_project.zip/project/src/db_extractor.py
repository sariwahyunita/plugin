"""
src/db_extractor.py
Koneksi ke SQL Server dan extract data polis via pyodbc.
Kredensial dibaca dari environment variable (.env).
"""

import logging
import os
from typing import Any

import pyodbc
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

# ── Query Constants ───────────────────────────────────────────────────────────
# Sesuaikan nama tabel dan kolom dengan skema DB aktual
QUERY_POLICY = """
    SELECT
        policy_number,
        product_name,
        insured_name,
        birth_date,
        gender,
        policy_status,
        start_date,
        end_date,
        sum_insured,
        annual_premium,
        beneficiary_name
    FROM policies
    WHERE policy_number = ?
"""

QUERY_TRANSACTIONS = """
    SELECT
        transaction_date,
        transaction_type,
        price_date,
        unit_amount,
        unit_price,
        transaction_value
    FROM policy_transactions
    WHERE policy_number = ?
    ORDER BY transaction_date ASC
"""


def _get_connection() -> pyodbc.Connection:
    """
    Buat koneksi ke SQL Server menggunakan environment variable.

    Returns:
        pyodbc.Connection object

    Raises:
        ConnectionError: Jika koneksi gagal
    """
    driver   = os.getenv("DB_DRIVER", "ODBC Driver 17 for SQL Server")
    host     = os.getenv("DB_HOST", "localhost")
    port     = os.getenv("DB_PORT", "1433")
    database = os.getenv("DB_NAME", "")
    user     = os.getenv("DB_USER", "")
    password = os.getenv("DB_PASSWORD", "")

    conn_str = (
        f"DRIVER={{{driver}}};"
        f"SERVER={host},{port};"
        f"DATABASE={database};"
        f"UID={user};"
        f"PWD={password};"
        f"TrustServerCertificate=yes;"
    )

    try:
        conn = pyodbc.connect(conn_str, timeout=10)
        logger.debug("Koneksi SQL Server berhasil.")
        return conn
    except pyodbc.Error as e:
        raise ConnectionError(
            f"Gagal koneksi ke SQL Server ({host}:{port}/{database}).\n"
            f"Detail: {e}"
        )


def extract_policy_data(policy_number: str) -> dict[str, Any]:
    """
    Query data detail polis berdasarkan policy_number.

    Args:
        policy_number: Nomor polis yang dicari

    Returns:
        dict data polis. Kosong {} jika tidak ditemukan.
    """
    conn = None
    try:
        conn = _get_connection()
        cursor = conn.cursor()
        cursor.execute(QUERY_POLICY, (policy_number,))
        row = cursor.fetchone()

        if row is None:
            logger.warning(f"Data polis tidak ditemukan di DB: {policy_number}")
            return {}

        columns = [col[0] for col in cursor.description]
        result  = dict(zip(columns, row))
        logger.info(f"Data polis berhasil di-extract dari DB: {policy_number}")
        return result

    except pyodbc.Error as e:
        logger.error(f"Error query DB untuk policy {policy_number}: {e}")
        raise
    finally:
        if conn:
            conn.close()


def extract_transaction_data(policy_number: str) -> list[dict[str, Any]]:
    """
    Query semua baris transaksi untuk policy_number.

    Args:
        policy_number: Nomor polis yang dicari

    Returns:
        list of dict. Kosong [] jika tidak ada data.
    """
    conn = None
    try:
        conn = _get_connection()
        cursor = conn.cursor()
        cursor.execute(QUERY_TRANSACTIONS, (policy_number,))
        rows = cursor.fetchall()

        if not rows:
            logger.warning(f"Tidak ada data transaksi untuk policy: {policy_number}")
            return []

        columns = [col[0] for col in cursor.description]
        result  = [dict(zip(columns, row)) for row in rows]
        logger.info(f"{len(result)} baris transaksi di-extract untuk: {policy_number}")
        return result

    except pyodbc.Error as e:
        logger.error(f"Error query transaksi untuk policy {policy_number}: {e}")
        raise
    finally:
        if conn:
            conn.close()
