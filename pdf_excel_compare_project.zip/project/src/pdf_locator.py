"""
src/pdf_locator.py
Cari file PDF berdasarkan nomor polis di folder PDF.
Nama file PDF harus mengandung nomor polis di dalamnya.
Contoh: "laporan_510-7071457_mei2026.pdf", "510-7071457.pdf"
"""

import logging
from pathlib import Path

import pdfplumber

logger = logging.getLogger(__name__)


def find_pdf(policy_number: str, pdf_folder: str) -> str | None:
    """
    Cari file PDF yang namanya mengandung policy_number di pdf_folder.

    Args:
        policy_number: Nomor polis yang dicari
        pdf_folder: Path folder tempat file PDF disimpan

    Returns:
        Full path file PDF jika ditemukan, None jika tidak.
    """
    folder = Path(pdf_folder)

    if not folder.exists():
        logger.error(f"Folder PDF tidak ditemukan: {pdf_folder}")
        return None

    # Cari semua .pdf yang namanya mengandung policy_number (case-insensitive)
    matches = [
        f for f in folder.glob("*.pdf")
        if policy_number.lower() in f.name.lower()
    ]

    if not matches:
        logger.warning(f"File PDF tidak ditemukan untuk policy: {policy_number}")
        return None

    if len(matches) > 1:
        logger.warning(
            f"Ditemukan {len(matches)} file PDF untuk policy {policy_number}. "
            f"Menggunakan file pertama: {matches[0].name}"
        )

    logger.info(f"PDF ditemukan: {matches[0].name}")
    return str(matches[0])


def validate_pdf(pdf_path: str) -> bool:
    """
    Validasi bahwa file PDF bisa dibuka dan tidak corrupt.

    Args:
        pdf_path: Full path ke file PDF

    Returns:
        True jika valid, False jika corrupt atau bukan PDF.
    """
    try:
        with pdfplumber.open(pdf_path) as pdf:
            # Coba baca halaman pertama sebagai validasi dasar
            _ = pdf.pages[0].extract_text()
        return True
    except Exception as e:
        logger.error(f"File PDF tidak valid atau corrupt: {pdf_path}\nDetail: {e}")
        return False
