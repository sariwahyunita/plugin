"""
src/report_generator.py
Generate file Excel report detail per policy number.
Satu file report per policy, disimpan di subfolder reports/.
"""

import logging
from datetime import datetime
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from src.comparator import FieldResult, PolicyResult

logger = logging.getLogger(__name__)

# ── Konstanta Warna ───────────────────────────────────────────────────────────
COLOR_HEADER     = "003366"   # Biru tua — header
COLOR_INFO_BG    = "EEF4FF"   # Biru sangat muda — info bar
COLOR_MATCH      = "D6F5E3"   # Hijau muda — MATCH
COLOR_MISMATCH   = "FFE0E0"   # Merah muda — MISMATCH
COLOR_PASS       = "1A7A3C"   # Hijau tua — summary PASS
COLOR_FAIL       = "CC0000"   # Merah tua — summary FAIL
COLOR_ERROR      = "FF8C00"   # Oranye — summary ERROR
FONT_WHITE       = "FFFFFF"
FONT_MATCH       = "1A7A3C"
FONT_MISMATCH    = "CC0000"
FONT_DARK        = "111111"


# ── Style Helpers ─────────────────────────────────────────────────────────────

def _border() -> Border:
    side = Side(style="thin", color="CCCCCC")
    return Border(left=side, right=side, top=side, bottom=side)


def _apply_header_style(cell, bg_color: str = COLOR_HEADER) -> None:
    """Header: font putih bold, background warna, center, border."""
    cell.font      = Font(name="Arial", bold=True, color=FONT_WHITE, size=10)
    cell.fill      = PatternFill("solid", start_color=bg_color, end_color=bg_color)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border    = _border()


def _apply_data_style(cell, bg_color: str = "FFFFFF", bold: bool = False) -> None:
    """Data cell: font Arial, background, border, wrap text."""
    cell.font      = Font(name="Arial", size=9, bold=bold)
    cell.fill      = PatternFill("solid", start_color=bg_color, end_color=bg_color)
    cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    cell.border    = _border()


def _apply_value_style(cell, is_match: bool) -> None:
    """Nilai PDF/Excel: warna hijau jika match, merah jika tidak."""
    color     = FONT_MATCH if is_match else FONT_MISMATCH
    bg_color  = COLOR_MATCH if is_match else COLOR_MISMATCH
    cell.font = Font(name="Arial", size=9, bold=not is_match, color=color)
    cell.fill = PatternFill("solid", start_color=bg_color, end_color=bg_color)
    cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    cell.border    = _border()


def _apply_summary_style(cell, status: str) -> None:
    """Summary row: font putih bold, warna sesuai status."""
    color_map  = {"PASS": COLOR_PASS, "FAIL": COLOR_FAIL, "ERROR": COLOR_ERROR}
    bg_color   = color_map.get(status.upper(), "888888")
    cell.font  = Font(name="Arial", bold=True, color=FONT_WHITE, size=10)
    cell.fill  = PatternFill("solid", start_color=bg_color, end_color=bg_color)
    cell.alignment = Alignment(horizontal="center", vertical="center")
    cell.border    = _border()


# ── Sheet Builder ─────────────────────────────────────────────────────────────

def _build_summary_sheet(ws, policy_result: PolicyResult) -> None:
    """Isi sheet Summary dengan header, data per field, dan summary row."""
    total     = len(policy_result.field_results)
    matched   = sum(1 for r in policy_result.field_results if r.is_match)
    mismatched = total - matched
    timestamp = datetime.now().strftime("%d %B %Y, %H:%M:%S")

    # ── Row 1: Title ──
    ws.merge_cells("A1:F1")
    title = ws["A1"]
    title.value     = f"COMPARISON REPORT — Policy {policy_result.policy_number}"
    title.font      = Font(name="Arial", bold=True, size=13, color=COLOR_HEADER)
    title.alignment = Alignment(horizontal="center", vertical="center")
    title.fill      = PatternFill("solid", start_color=COLOR_INFO_BG, end_color=COLOR_INFO_BG)
    ws.row_dimensions[1].height = 30

    # ── Row 2: Info ──
    ws.merge_cells("A2:F2")
    info = ws["A2"]
    info.value = (
        f"Generated: {timestamp}  |  Test Case: {policy_result.test_case_id}  |  "
        f"Total: {total}  |  Match: {matched}  |  Mismatch: {mismatched}"
    )
    info.font      = Font(name="Arial", size=8, italic=True, color="666666")
    info.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[2].height = 16

    # ── Row 3: Header kolom ──
    headers    = ["No", "Field", "Kolom Excel", "Nilai PDF", "Nilai DB/Excel", "Status"]
    col_widths = [5,    22,      25,            28,          28,               12]

    for col_idx, (h, w) in enumerate(zip(headers, col_widths), start=1):
        cell = ws.cell(row=3, column=col_idx, value=h)
        _apply_header_style(cell)
        ws.column_dimensions[get_column_letter(col_idx)].width = w
    ws.row_dimensions[3].height = 24

    # ── Row 4+: Data per field ──
    for row_idx, r in enumerate(policy_result.field_results, start=4):
        bg   = COLOR_MATCH if r.is_match else COLOR_MISMATCH
        icon = "✅ MATCH" if r.is_match else "❌ MISMATCH"

        cells_data = [row_idx - 3, r.field, r.excel_column, r.pdf_value, r.excel_value, icon]
        for col_idx, val in enumerate(cells_data, start=1):
            cell = ws.cell(row=row_idx, column=col_idx, value=val)
            if col_idx in (4, 5):
                _apply_value_style(cell, r.is_match)
            elif col_idx == 6:
                _apply_summary_style(cell, "PASS" if r.is_match else "FAIL")
            else:
                _apply_data_style(cell, bg)
        ws.row_dimensions[row_idx].height = 20

        # Tambahkan note jika ada
        if r.note:
            ws.cell(row=row_idx, column=6).comment = None  # placeholder untuk note

    # ── Last row: Summary ──
    summary_row = len(policy_result.field_results) + 4
    ws.merge_cells(f"A{summary_row}:C{summary_row}")
    label = ws.cell(row=summary_row, column=1, value="OVERALL RESULT")
    _apply_header_style(label)

    ws.merge_cells(f"D{summary_row}:F{summary_row}")
    result_text = (
        f"✅ PASSED ({matched}/{total} fields match)"
        if policy_result.status == "PASS"
        else f"❌ FAILED ({mismatched}/{total} fields mismatch)"
    )
    result_cell = ws.cell(row=summary_row, column=4, value=result_text)
    _apply_summary_style(result_cell, policy_result.status)
    ws.row_dimensions[summary_row].height = 26

    ws.freeze_panes = "A4"


def _build_transaction_sheet(ws, tx_results: list[FieldResult]) -> None:
    """Isi sheet Transaction Detail dengan data compare per baris transaksi."""
    headers    = ["No", "Key", "Field", "Nilai PDF", "Nilai DB", "Status"]
    col_widths = [5,    30,    20,      25,          25,         12]

    for col_idx, (h, w) in enumerate(zip(headers, col_widths), start=1):
        cell = ws.cell(row=1, column=col_idx, value=h)
        _apply_header_style(cell)
        ws.column_dimensions[get_column_letter(col_idx)].width = w
    ws.row_dimensions[1].height = 24

    for row_idx, r in enumerate(tx_results, start=2):
        # Field format: "key | col"
        parts = r.field.split(" → ", 1)
        key   = parts[0] if len(parts) > 1 else ""
        col   = parts[1] if len(parts) > 1 else r.field
        icon  = "✅" if r.is_match else "❌"

        for col_idx, val in enumerate(
            [row_idx - 1, key, col, r.pdf_value, r.excel_value, icon], start=1
        ):
            cell = ws.cell(row=row_idx, column=col_idx, value=val)
            bg   = COLOR_MATCH if r.is_match else COLOR_MISMATCH
            _apply_data_style(cell, bg)
        ws.row_dimensions[row_idx].height = 18

    ws.freeze_panes = "A2"


# ── Main Builder ──────────────────────────────────────────────────────────────

def build_report(policy_result: PolicyResult, output_dir: str) -> str:
    """
    Generate file Excel report untuk satu policy.

    Args:
        policy_result: PolicyResult dari comparator
        output_dir: Path folder reports/ di dalam result folder

    Returns:
        Path file report yang dihasilkan
    """
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    safe_policy = policy_result.policy_number.replace("/", "-").replace("\\", "-")
    output_path = Path(output_dir) / f"report_{safe_policy}.xlsx"

    wb = Workbook()
    ws_summary = wb.active
    ws_summary.title = "Summary"
    _build_summary_sheet(ws_summary, policy_result)

    # Sheet transaksi hanya jika ada data transaksi
    tx_results = [r for r in policy_result.field_results if " → " in r.field]
    if tx_results:
        ws_tx = wb.create_sheet("Transaction Detail")
        _build_transaction_sheet(ws_tx, tx_results)

    wb.save(output_path)
    logger.info(f"Report disimpan: {output_path}")
    return str(output_path)
