"""
src/pdf_extractor.py
Semua strategi extract data dari PDF.
Strategi yang dipakai ditentukan oleh config YAML per produk.

Strategi tersedia:
  1. regex               — label eksplisit: "Nama : ..."
  2. anchor_offset       — data tanpa label, cari via teks tetangga
  3. positional          — urutan baris dalam section selalu konsisten
  4. pattern_recognition — kenali field dari karakteristik konten
  5. extract_table       — tabel grid dengan border
  6. crop_columns        — layout dua kolom
  7. post_processing     — tabel kompleks: multi-baris, group header, nilai negatif
"""

import logging
import re
from pathlib import Path

import pandas as pd
import pdfplumber

logger = logging.getLogger(__name__)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _parse_nilai_indonesia(nilai: str) -> float | None:
    """
    Konversi format angka Indonesia ke float.
    Handle: titik ribuan, koma desimal, dan format negatif kurung.
    Contoh: "(345.000,00)" → -345000.0, "27.822,1644" → 27822.1644
    """
    if not nilai:
        return None
    nilai = str(nilai).strip()
    negatif = nilai.startswith("(") and nilai.endswith(")")
    nilai   = nilai.strip("()").replace("Rp", "").replace(" ", "").strip()
    nilai   = nilai.replace(".", "").replace(",", ".")
    try:
        result = float(nilai)
        return -result if negatif else result
    except ValueError:
        return None


def _strip_numeric(nilai: str) -> str:
    """Strip format Rupiah: hapus Rp, titik ribuan, koma desimal → string integer."""
    if not nilai:
        return nilai
    cleaned = str(nilai).replace("Rp", "").replace("Rp.", "").strip()
    cleaned = cleaned.replace(".", "").replace(",", "")
    return cleaned.strip()


def _extract_full_text(pdf_path: str) -> str:
    """Buka PDF dan gabungkan teks semua halaman."""
    with pdfplumber.open(pdf_path) as pdf:
        return "\n".join(page.extract_text() or "" for page in pdf.pages)


# ── Strategi 1: Regex ─────────────────────────────────────────────────────────

def extract_regex(
    full_text: str,
    patterns: dict[str, str],
    numeric_fields: set[str],
) -> dict[str, str | None]:
    """
    Extract field menggunakan regex pattern dari config YAML.

    Args:
        full_text: Teks gabungan semua halaman PDF
        patterns: dict {field_name: regex_pattern}
        numeric_fields: set field yang nilainya numerik (strip Rp, titik, koma)

    Returns:
        dict {field_name: value | None}
    """
    result = {}
    for field, pattern in patterns.items():
        match = re.search(pattern, full_text, re.IGNORECASE)
        if match:
            raw = match.group(1).strip()
            result[field] = _strip_numeric(raw) if field in numeric_fields else raw
        else:
            result[field] = None
            logger.warning(f"  [regex] Field tidak ditemukan: {field}")
    return result


# ── Strategi 2: Anchor + Offset ───────────────────────────────────────────────

def extract_anchor_offset(
    full_text: str,
    anchor_config: dict,
) -> dict[str, str | None]:
    """
    Extract field tanpa label menggunakan teks anchor sebagai patokan.

    Args:
        full_text: Teks gabungan semua halaman PDF
        anchor_config: dict dari YAML berisi anchor_text, offset, dan pattern kota

    Returns:
        dict {field_name: value | None}
    """
    result: dict[str, str | None] = {
        "nama_tujuan": None,
        "alamat":      None,
        "kota":        None,
    }

    anchor_text   = anchor_config.get("anchor_text", "Kepada Yth.")
    nama_offset   = anchor_config.get("nama_offset", 1)
    alamat_start  = anchor_config.get("alamat_start", 2)
    kota_pattern  = anchor_config.get("kota_pattern", r"^(JAKARTA|BANDUNG|SURABAYA)")

    lines = full_text.splitlines()
    for i, line in enumerate(lines):
        if anchor_text.lower() in line.lower():
            sisa = [l.strip() for l in lines[i + 1:i + 10] if l.strip()]
            if len(sisa) >= nama_offset:
                result["nama_tujuan"] = sisa[nama_offset - 1]

            alamat_lines: list[str] = []
            for baris in sisa[alamat_start - 1:]:
                if re.match(kota_pattern, baris, re.IGNORECASE):
                    result["kota"] = baris
                    break
                alamat_lines.append(baris)

            result["alamat"] = " ".join(alamat_lines) if alamat_lines else None
            break

    return result


# ── Strategi 3: Positional ────────────────────────────────────────────────────

def extract_by_position(
    full_text: str,
    section_header: str,
    field_order: list[str],
) -> dict[str, str | None]:
    """
    Extract field berdasarkan urutan baris dalam section.

    Args:
        full_text: Teks gabungan PDF
        section_header: Teks header section sebagai penanda awal data
        field_order: list nama field sesuai urutan baris dalam section

    Returns:
        dict {field_name: value | None}
    """
    result: dict[str, str | None] = {f: None for f in field_order}
    lines  = full_text.splitlines()

    for i, line in enumerate(lines):
        if section_header.lower() in line.lower():
            data_lines = [l.strip() for l in lines[i + 1:] if l.strip()]
            for idx, field in enumerate(field_order):
                result[field] = data_lines[idx] if idx < len(data_lines) else None
            break

    return result


# ── Strategi 4: Pattern Recognition ──────────────────────────────────────────

def extract_pattern_recognition(lines: list[str]) -> dict[str, str | None]:
    """
    Klasifikasi dan extract field berdasarkan karakteristik konten baris.

    Args:
        lines: list baris teks dari section yang akan di-extract

    Returns:
        dict {field_name: value | None}
    """
    result: dict[str, str | None] = {
        "nama":    None,
        "ktp":     None,
        "alamat":  None,
        "kota":    None,
    }

    for line in lines:
        line = line.strip()
        if not line:
            continue

        # KTP: 16 digit angka
        if re.match(r"^\d{16}$", line):
            result["ktp"] = line

        # Alamat: mengandung Jl./Jalan/Gang/Komplek
        elif re.search(r"\b(jl\.|jalan|gang|gg\.|komplek|kp\.)\b", line, re.IGNORECASE):
            result["alamat"] = line

        # Kota: semua huruf kapital, tidak ada angka, minimal 3 karakter
        elif re.match(r"^[A-Z\s]{3,}$", line) and not result["kota"]:
            result["kota"] = line

        # Nama: huruf semua (termasuk spasi), minimal 2 kata, belum terisi
        elif re.match(r"^[A-Za-z\s]+$", line) and len(line.split()) >= 2 and not result["nama"]:
            result["nama"] = line

    return result


# ── Strategi 5: Extract Table ─────────────────────────────────────────────────

def extract_table_simple(
    page,
    table_anchor: str,
    table_settings: dict | None = None,
) -> pd.DataFrame:
    """
    Extract tabel dari satu halaman PDF menggunakan pdfplumber.

    Args:
        page: pdfplumber page object
        table_anchor: kata kunci di header tabel untuk memastikan tabel yang benar
        table_settings: opsional, override table detection settings

    Returns:
        DataFrame hasil extract. Kosong jika tidak ditemukan.
    """
    settings = table_settings or {}
    tables   = page.extract_tables(settings) if settings else page.extract_tables()

    for table in tables:
        if not table or len(table) < 2:
            continue
        header_flat = " ".join(str(c) for c in table[0] if c)
        if table_anchor.lower() in header_flat.lower():
            df = pd.DataFrame(table[1:], columns=table[0])
            df.columns = [str(c).strip() for c in df.columns]
            return df

    logger.warning(f"Tabel dengan anchor '{table_anchor}' tidak ditemukan.")
    return pd.DataFrame()


# ── Strategi 6: Crop per Kolom ───────────────────────────────────────────────

def extract_crop_columns(
    page,
    crop_config: dict,
) -> tuple[str, str]:
    """
    Crop halaman jadi dua area dan extract teks masing-masing kolom.

    Args:
        page: pdfplumber page object
        crop_config: dict berisi koordinat rasio [x0, y0, x1, y1] untuk left dan right

    Returns:
        tuple (teks_kiri, teks_kanan)
    """
    w = page.width
    h = page.height

    left_ratio  = crop_config.get("left",  [0,   0, 0.5, 1])
    right_ratio = crop_config.get("right", [0.5, 0, 1,   1])

    left_bbox  = (left_ratio[0]  * w, left_ratio[1]  * h, left_ratio[2]  * w, left_ratio[3]  * h)
    right_bbox = (right_ratio[0] * w, right_ratio[1] * h, right_ratio[2] * w, right_ratio[3] * h)

    teks_kiri  = page.crop(left_bbox).extract_text()  or ""
    teks_kanan = page.crop(right_bbox).extract_text() or ""

    return teks_kiri, teks_kanan


# ── Strategi 7: Post-processing Pipeline ─────────────────────────────────────

def _classify_row(row: list) -> str:
    """Klasifikasi jenis baris tabel untuk post-processing."""
    if not any(row):
        return "empty"
    first  = str(row[0]).strip() if row[0] else ""
    second = str(row[1]).strip() if len(row) > 1 and row[1] else ""

    if first.isupper() and len(first) > 5 and not any(str(c).strip() for c in row[1:] if c):
        return "group_header"
    if "saldo awal" in second.lower():
        return "saldo_awal"
    if "tanggal transaksi" in first.lower() or "jenis transaksi" in second.lower():
        return "header"
    if not first and second:
        return "continuation"
    if re.match(r"\d{1,2}\s+\w+\s+\d{4}", first):
        return "data"
    return "unknown"


def _merge_continuation_rows(raw_rows: list[list]) -> list[list]:
    """Gabungkan baris lanjutan (continuation) ke baris data sebelumnya."""
    cleaned: list[list] = []
    buffer: list | None = None

    for row in raw_rows:
        row_type = _classify_row(row)

        if row_type in ("empty", "header", "group_header", "saldo_awal", "unknown"):
            if buffer:
                cleaned.append(buffer)
                buffer = None
            continue

        if row_type == "data":
            if buffer:
                cleaned.append(buffer)
            buffer = [str(c).strip() if c else "" for c in row]

        elif row_type == "continuation" and buffer is not None:
            # Sambungkan teks di kolom kedua (Jenis Transaksi)
            if row[1]:
                buffer[1] = (buffer[1] + " " + str(row[1]).strip()).strip()

    if buffer:
        cleaned.append(buffer)

    return cleaned


def extract_post_processing(
    pdf_path: str,
    table_anchor: str,
    columns: list[str],
    numeric_columns: list[str] | None = None,
    table_settings: dict | None = None,
) -> pd.DataFrame:
    """
    Pipeline lengkap untuk tabel kompleks dengan ratusan baris.
    Handles: group header, continuation rows, nilai negatif format kurung.

    Args:
        pdf_path: Path ke file PDF
        table_anchor: Kata kunci di header tabel
        columns: Nama kolom output DataFrame
        numeric_columns: Kolom yang nilainya perlu dikonversi ke float
        table_settings: Override table detection settings jika tabel tanpa border

    Returns:
        DataFrame bersih hasil extract.
    """
    raw_rows: list[list] = []
    settings = table_settings or {}

    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            tables = page.extract_tables(settings) if settings else page.extract_tables()
            for table in tables:
                if not table:
                    continue
                header_flat = " ".join(str(c) for c in table[0] if c)
                if table_anchor.lower() in header_flat.lower():
                    raw_rows.extend(table[1:])  # skip header row

    if not raw_rows:
        logger.warning(f"Post-processing: tabel '{table_anchor}' tidak ditemukan.")
        return pd.DataFrame(columns=columns)

    cleaned = _merge_continuation_rows(raw_rows)

    # Pad atau trim kolom agar konsisten
    padded = [(row + [""] * len(columns))[:len(columns)] for row in cleaned]
    df     = pd.DataFrame(padded, columns=columns)

    # Konversi kolom numerik
    for col in (numeric_columns or []):
        if col in df.columns:
            df[col] = df[col].apply(_parse_nilai_indonesia)

    logger.info(f"Post-processing selesai: {len(df)} baris ditemukan.")
    return df


# ── Router Utama ──────────────────────────────────────────────────────────────

def extract_proposal(pdf_path: str, config: dict) -> dict:
    """
    Fungsi utama — routing ke strategi yang sesuai berdasarkan config YAML.

    Args:
        pdf_path: Path ke file PDF
        config: dict config produk dari config_loader

    Returns:
        dict lengkap hasil extract semua field
    """
    path     = Path(pdf_path)
    strategy = config.get("extract_strategy", {})
    patterns = config.get("pdf_patterns", {})
    numeric  = set(config.get("numeric_fields", []))
    result: dict = {}

    logger.info(f"Extracting PDF: {path.name}")

    with pdfplumber.open(pdf_path) as pdf:
        first_page = pdf.pages[0]

        # ── Crop dua kolom jika ada config-nya ──
        if "column_crop" in config and strategy.get("header_left") and strategy.get("header_right"):
            teks_kiri, teks_kanan = extract_crop_columns(first_page, config["column_crop"])

            if strategy.get("header_left") == "anchor_offset":
                left_data = extract_anchor_offset(teks_kiri, config.get("anchor_left", {}))
                result.update(left_data)

            if strategy.get("header_right") == "regex":
                right_data = extract_regex(teks_kanan, patterns, numeric)
                result.update(right_data)

        # ── Regex pada full text (tanpa crop) ──
        elif strategy.get("header") == "regex":
            full_text = "\n".join(page.extract_text() or "" for page in pdf.pages)
            result.update(extract_regex(full_text, patterns, numeric))

        # ── Extract tabel summary ──
        if strategy.get("summary_table") == "extract_table":
            anchor = config.get("summary_table_anchor", "Rangkuman Transaksi")
            df     = extract_table_simple(first_page, anchor, config.get("table_settings"))
            if not df.empty:
                result["summary_table"] = df.to_dict(orient="records")

    # ── Post-processing untuk tabel transaksi detail (multi-page) ──
    if strategy.get("detail_table") == "post_processing":
        anchor  = config.get("detail_table_anchor", "Rincian Transaksi")
        cols    = config.get("transaction_table_columns", [])
        num_col = config.get("transaction_numeric_columns", [])
        df      = extract_post_processing(pdf_path, anchor, cols, num_col, config.get("table_settings"))
        if not df.empty:
            result["detail_table"] = df.to_dict(orient="records")

    logger.info(f"Extract selesai. {len(result)} field/section ditemukan.")
    return result
