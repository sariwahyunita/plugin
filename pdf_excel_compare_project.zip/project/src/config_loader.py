"""
src/config_loader.py
Load dan validasi YAML config per produk asuransi.
Setiap produk memiliki file config sendiri di config/products/.
"""

import logging
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)

# Lokasi folder config relatif terhadap root project
CONFIG_DIR = Path(__file__).parent.parent / "config" / "products"

# Key wajib yang harus ada di setiap file YAML config
REQUIRED_KEYS = [
    "metadata",
    "key_column",
    "extract_strategy",
    "excel_column_map",
    "numeric_fields",
]


def load_config(product_code: str) -> dict:
    """
    Load file YAML config berdasarkan kode produk.

    Args:
        product_code: Nama file YAML tanpa ekstensi. Contoh: "axa_mandiri"

    Returns:
        dict berisi konfigurasi produk

    Raises:
        FileNotFoundError: Jika file config tidak ditemukan
        yaml.YAMLError: Jika file YAML tidak valid
    """
    config_path = CONFIG_DIR / f"{product_code}.yaml"

    if not config_path.exists():
        available = list_available_products()
        raise FileNotFoundError(
            f"Config untuk produk '{product_code}' tidak ditemukan.\n"
            f"File yang dicari: {config_path}\n"
            f"Produk tersedia: {available}"
        )

    logger.info(f"Loading config: {config_path.name}")

    try:
        with open(config_path, encoding="utf-8") as f:
            config = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise yaml.YAMLError(f"File config tidak valid: {config_path}\nDetail: {e}")

    validate_config(config, product_code)
    return config


def validate_config(config: dict, product_code: str) -> None:
    """
    Validasi bahwa semua key wajib ada di config.

    Args:
        config: dict hasil load YAML
        product_code: kode produk untuk pesan error

    Raises:
        ValueError: Jika ada key wajib yang tidak ada
    """
    missing = [key for key in REQUIRED_KEYS if key not in config]
    if missing:
        raise ValueError(
            f"Config '{product_code}' tidak lengkap.\n"
            f"Key yang hilang: {missing}\n"
            f"Key wajib: {REQUIRED_KEYS}"
        )
    logger.debug(f"Config '{product_code}' valid.")


def list_available_products() -> list[str]:
    """
    Kembalikan list kode produk yang tersedia (nama file .yaml di config/products/).

    Returns:
        list of str kode produk
    """
    if not CONFIG_DIR.exists():
        return []
    return [f.stem for f in CONFIG_DIR.glob("*.yaml")]
