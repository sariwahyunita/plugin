"""
src/comparator.py
Logic compare data PDF vs data DB field by field.
Tidak ada I/O di file ini — pure logic, mudah di-unit-test.
"""

import logging
from dataclasses import dataclass, field

import pandas as pd

logger = logging.getLogger(__name__)


@dataclass
class FieldResult:
    """Hasil compare untuk satu field."""
    field:        str
    excel_column: str
    pdf_value:    str | None
    excel_value:  str | None
    is_match:     bool
    note:         str | None = None


@dataclass
class PolicyResult:
    """Hasil compare untuk satu policy number."""
    policy_number:   str
    test_case_id:    str
    status:          str           # PASS / FAIL / ERROR
    field_results:   list[FieldResult] = field(default_factory=list)
    mismatch_fields: list[str]         = field(default_factory=list)
    notes:           str | None        = None


def normalize_value(value) -> str:
    """
    Normalisasi nilai untuk perbandingan: strip whitespace, lowercase.
    Handle None → "", float → string integer.

    Args:
        value: nilai yang akan dinormalisasi

    Returns:
        string yang sudah dinormalisasi
    """
    if value is None:
        return ""
    if isinstance(value, float) and value == int(value):
        return str(int(value))
    return str(value).strip().lower()


def compare_field(
    field_name: str,
    excel_col: str,
    pdf_val,
    excel_val,
) -> FieldResult:
    """
    Compare satu field antara PDF dan Excel/DB.

    Args:
        field_name: Nama field (dari config)
        excel_col: Nama kolom Excel
        pdf_val: Nilai dari PDF
        excel_val: Nilai dari DB/Excel

    Returns:
        FieldResult dengan detail perbandingan
    """
    norm_pdf   = normalize_value(pdf_val)
    norm_excel = normalize_value(excel_val)
    is_match   = norm_pdf == norm_excel

    note = None
    if pdf_val is None:
        note = "Field tidak ditemukan di PDF"
    elif excel_val is None:
        note = "Field tidak ditemukan di DB"

    return FieldResult(
        field        = field_name,
        excel_column = excel_col,
        pdf_value    = pdf_val,
        excel_value  = excel_val,
        is_match     = is_match,
        note         = note,
    )


def compare_transaction_table(
    df_pdf: pd.DataFrame,
    df_db: pd.DataFrame,
    key_columns: list[str],
) -> list[FieldResult]:
    """
    Compare tabel transaksi detail baris per baris.

    Args:
        df_pdf: DataFrame hasil extract dari PDF
        df_db: DataFrame hasil query dari DB
        key_columns: Kolom yang dipakai sebagai composite key (merge key)

    Returns:
        list FieldResult — satu entry per kombinasi baris + kolom
    """
    results: list[FieldResult] = []

    # Normalize kolom key sebelum merge
    for col in key_columns:
        if col in df_pdf.columns:
            df_pdf[col] = df_pdf[col].astype(str).str.strip().str.lower()
        if col in df_db.columns:
            df_db[col]  = df_db[col].astype(str).str.strip().str.lower()

    merged = df_pdf.merge(
        df_db,
        on=key_columns,
        suffixes=("_pdf", "_db"),
        how="outer",
        indicator=True,
    )

    value_cols = [
        c.replace("_pdf", "") for c in merged.columns
        if c.endswith("_pdf")
    ]

    for _, row in merged.iterrows():
        key_label = " | ".join(str(row.get(k, "")) for k in key_columns)
        for col in value_cols:
            pdf_val   = row.get(f"{col}_pdf")
            db_val    = row.get(f"{col}_db")
            is_match  = normalize_value(pdf_val) == normalize_value(db_val)
            results.append(FieldResult(
                field        = f"{key_label} → {col}",
                excel_column = col,
                pdf_value    = pdf_val,
                excel_value  = db_val,
                is_match     = is_match,
            ))

    return results


def compare_policy(
    pdf_data: dict,
    db_data: dict,
    config: dict,
    policy_number: str,
    test_case_id: str,
) -> PolicyResult:
    """
    Compare semua field untuk satu policy number.

    Args:
        pdf_data: dict hasil extract PDF
        db_data: dict hasil query DB
        config: dict config produk dari config_loader
        policy_number: Nomor polis
        test_case_id: ID test case

    Returns:
        PolicyResult lengkap dengan status PASS/FAIL
    """
    column_map = config.get("excel_column_map", {})
    field_results: list[FieldResult] = []

    # Compare field-level data (header)
    for field_name, excel_col in column_map.items():
        # Skip field yang merupakan key tabel (bukan scalar)
        if field_name in ("summary_table", "detail_table"):
            continue
        pdf_val   = pdf_data.get(field_name)
        db_val    = db_data.get(field_name)
        result    = compare_field(field_name, excel_col, pdf_val, db_val)
        field_results.append(result)

    # Compare tabel transaksi detail jika ada
    if "detail_table" in pdf_data and pdf_data["detail_table"]:
        tx_cols     = config.get("transaction_table_columns", [])
        key_cols    = config.get("transaction_key_columns", tx_cols[:2])
        df_pdf_tx   = pd.DataFrame(pdf_data["detail_table"])
        df_db_tx    = pd.DataFrame(db_data.get("transactions", []))

        if not df_pdf_tx.empty and not df_db_tx.empty:
            tx_results = compare_transaction_table(df_pdf_tx, df_db_tx, key_cols)
            field_results.extend(tx_results)

    # Tentukan status akhir
    mismatch = [r.field for r in field_results if not r.is_match]
    status   = "PASS" if not mismatch else "FAIL"

    logger.info(
        f"Compare selesai [{policy_number}]: {status} — "
        f"{len(field_results) - len(mismatch)}/{len(field_results)} fields match"
    )

    return PolicyResult(
        policy_number   = policy_number,
        test_case_id    = test_case_id,
        status          = status,
        field_results   = field_results,
        mismatch_fields = mismatch,
    )
