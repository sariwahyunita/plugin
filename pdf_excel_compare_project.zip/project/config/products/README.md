# Panduan Menambah Produk Baru

Setiap produk asuransi memiliki file YAML sendiri di folder ini.

## Cara Menambah Produk Baru

1. Salin file config produk yang sudah ada sebagai template:
   ```
   cp axa_mandiri.yaml nama_produk_baru.yaml
   ```

2. Edit file YAML baru — sesuaikan setiap section dengan layout PDF produk tersebut.

3. Gunakan `product_code` yang sama dengan nama file (tanpa .yaml) di kolom
   `product_code` pada file testcase.xlsx.

## Strategi Extract yang Tersedia

| Strategi | Kapan Dipakai |
|---|---|
| `regex` | Ada label eksplisit: "Nama : ..." |
| `anchor_offset` | Data tanpa label, ada teks tetangga unik |
| `positional` | Urutan baris dalam section selalu konsisten |
| `pattern_recognition` | Konten punya ciri khas (angka, format) |
| `extract_table` | Tabel grid dengan border garis |
| `crop_columns` | Layout dua kolom yang bisa tercampur |
| `post_processing` | Tabel kompleks: multi-baris, nilai negatif |

## Tips Debug Regex

Jika field tidak ditemukan, jalankan script ini untuk lihat teks mentah PDF:

```python
import pdfplumber
with pdfplumber.open("data/pdf/nama_file.pdf") as pdf:
    for i, page in enumerate(pdf.pages):
        print(f"--- PAGE {i+1} ---")
        print(page.extract_text())
```

Copy teks yang relevan ke https://regex101.com dan test pattern dengan flag IGNORECASE.
