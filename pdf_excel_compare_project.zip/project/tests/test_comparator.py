"""tests/test_comparator.py"""

import pytest

from src.comparator import (
    FieldResult,
    compare_field,
    compare_policy,
    normalize_value,
)


def test_normalize_value_strips_whitespace():
    assert normalize_value("  Aktif  ") == "aktif"


def test_normalize_value_case_insensitive():
    assert normalize_value("SITI RAHAYU") == normalize_value("siti rahayu")


def test_normalize_value_none():
    assert normalize_value(None) == ""


def test_normalize_value_float_integer():
    """Float yang nilainya bulat → string integer."""
    assert normalize_value(18750000.0) == "18750000"


def test_compare_field_match():
    """Nilai sama → is_match True."""
    result = compare_field("status_polis", "Status Polis", "Aktif", "Aktif")
    assert result.is_match is True


def test_compare_field_mismatch():
    """Nilai berbeda → is_match False."""
    result = compare_field("status_polis", "Status Polis", "Aktif", "Tidak Aktif")
    assert result.is_match is False


def test_compare_field_case_insensitive():
    """Perbandingan tidak case-sensitive."""
    result = compare_field("nama", "Nama", "siti rahayu", "Siti Rahayu")
    assert result.is_match is True


def test_compare_field_pdf_none():
    """PDF value None → is_match False, note terisi."""
    result = compare_field("no_polis", "No Polis", None, "510-7071457")
    assert result.is_match is False
    assert result.note is not None


def test_compare_policy_all_pass(sample_config, sample_db_data):
    """Semua field cocok → status PASS."""
    pdf_data = {
        "no_polis":           "510-7071457",
        "tertanggung":        "Siti Rahayu",
        "status_polis":       "Aktif",
        "uang_pertanggungan": "18750000",
    }
    result = compare_policy(
        pdf_data      = pdf_data,
        db_data       = sample_db_data,
        config        = sample_config,
        policy_number = "510-7071457",
        test_case_id  = "TC-001",
    )
    assert result.status == "PASS"
    assert result.mismatch_fields == []


def test_compare_policy_some_fail(sample_config, sample_db_data):
    """Ada field mismatch → status FAIL, mismatch_fields terisi."""
    pdf_data = {
        "no_polis":           "510-7071457",
        "tertanggung":        "NAMA BERBEDA",   # sengaja beda
        "status_polis":       "Aktif",
        "uang_pertanggungan": "18750000",
    }
    result = compare_policy(
        pdf_data      = pdf_data,
        db_data       = sample_db_data,
        config        = sample_config,
        policy_number = "510-7071457",
        test_case_id  = "TC-001",
    )
    assert result.status == "FAIL"
    assert "tertanggung" in result.mismatch_fields
