"""tests/test_db_extractor.py"""

from unittest.mock import MagicMock, patch

import pytest


def _make_mock_conn(rows, columns):
    """Helper: buat mock connection dengan hasil query tertentu."""
    mock_cursor = MagicMock()
    mock_cursor.fetchone.return_value  = rows[0] if rows else None
    mock_cursor.fetchall.return_value  = rows
    mock_cursor.description            = [(col,) for col in columns]
    mock_conn = MagicMock()
    mock_conn.cursor.return_value      = mock_cursor
    mock_conn.__enter__ = MagicMock(return_value=mock_conn)
    mock_conn.__exit__  = MagicMock(return_value=False)
    return mock_conn


def test_extract_policy_data_found():
    """Data ditemukan di DB → return dict berisi data polis."""
    columns = ["policy_number", "insured_name", "policy_status"]
    rows    = [("510-7071457", "Siti Rahayu", "Aktif")]
    mock_conn = _make_mock_conn(rows, columns)

    with patch("src.db_extractor._get_connection", return_value=mock_conn):
        from src.db_extractor import extract_policy_data
        result = extract_policy_data("510-7071457")

    assert result["policy_number"] == "510-7071457"
    assert result["insured_name"]  == "Siti Rahayu"


def test_extract_policy_data_not_found():
    """Data tidak ada di DB → return dict kosong {}."""
    mock_cursor = MagicMock()
    mock_cursor.fetchone.return_value = None
    mock_cursor.description           = [("policy_number",)]
    mock_conn = MagicMock()
    mock_conn.cursor.return_value     = mock_cursor

    with patch("src.db_extractor._get_connection", return_value=mock_conn):
        from src.db_extractor import extract_policy_data
        result = extract_policy_data("999-NOTFOUND")

    assert result == {}


def test_extract_transaction_data_empty():
    """Tidak ada data transaksi → return list kosong []."""
    mock_cursor = MagicMock()
    mock_cursor.fetchall.return_value = []
    mock_cursor.description           = [("tanggal_transaksi",)]
    mock_conn = MagicMock()
    mock_conn.cursor.return_value     = mock_cursor

    with patch("src.db_extractor._get_connection", return_value=mock_conn):
        from src.db_extractor import extract_transaction_data
        result = extract_transaction_data("510-7071457")

    assert result == []


def test_connection_failure():
    """Koneksi DB gagal → raise ConnectionError."""
    import pyodbc
    with patch("src.db_extractor.pyodbc.connect", side_effect=pyodbc.Error("conn failed")):
        from src.db_extractor import _get_connection
        with pytest.raises(ConnectionError, match="Gagal koneksi"):
            _get_connection()
