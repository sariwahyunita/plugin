"""tests/test_excel_handler.py"""

import pytest
import pandas as pd
from openpyxl import load_workbook, Workbook

from src.excel_handler import (
    duplicate_testcase,
    fill_db_data,
    read_testcase,
    update_row_status,
)


def _create_sample_testcase(path):
    """Helper: buat file testcase.xlsx sederhana untuk testing."""
    wb = Workbook()
    ws = wb.active
    ws.append(["test_case_id", "policy_number", "product_code",
                "insured_name", "status", "mismatch_fields", "notes"])
    ws.append(["TC-001", "510-7071457", "axa_mandiri", "", "", "", ""])
    ws.append(["TC-002", "510-7071458", "axa_mandiri", "", "", "", ""])
    wb.save(path)


def test_read_testcase_valid(tmp_path):
    """File valid dengan kolom wajib → return DataFrame."""
    path = str(tmp_path / "testcase.xlsx")
    _create_sample_testcase(path)
    df = read_testcase(path)
    assert len(df) == 2
    assert "policy_number" in df.columns


def test_read_testcase_missing_column(tmp_path):
    """Kolom wajib tidak ada → raise ValueError."""
    wb = Workbook()
    ws = wb.active
    ws.append(["test_case_id", "policy_number"])  # tidak ada product_code dan status
    path = str(tmp_path / "bad.xlsx")
    wb.save(path)

    with pytest.raises(ValueError, match="Kolom yang hilang"):
        read_testcase(path)


def test_read_testcase_file_not_found():
    """File tidak ada → raise FileNotFoundError."""
    with pytest.raises(FileNotFoundError):
        read_testcase("/path/tidak/ada/testcase.xlsx")


def test_duplicate_testcase(tmp_path):
    """File berhasil diduplikat ke folder result."""
    src = str(tmp_path / "testcase.xlsx")
    _create_sample_testcase(src)
    result_folder = str(tmp_path / "results" / "20240601_120000")
    import os
    os.makedirs(result_folder, exist_ok=True)

    dst = duplicate_testcase(src, result_folder)
    assert dst.endswith("testcase_result.xlsx")

    import pathlib
    assert pathlib.Path(dst).exists()


def test_update_row_status_pass(tmp_path):
    """Status PASS → sel status berwarna hijau."""
    path = str(tmp_path / "result.xlsx")
    _create_sample_testcase(path)

    update_row_status(path, "TC-001", "PASS")

    wb = load_workbook(path)
    ws = wb.active
    status_col = None
    for cell in ws[1]:
        if cell.value == "status":
            status_col = cell.column
            break

    # Cari baris TC-001
    for row in ws.iter_rows(min_row=2):
        if row[0].value == "TC-001":
            status_cell = ws.cell(row=row[0].row, column=status_col)
            assert status_cell.value == "PASS"
            assert status_cell.fill.fgColor.rgb.endswith("D6F5E3")
            break


def test_update_row_status_fail(tmp_path):
    """Status FAIL → sel status berwarna merah."""
    path = str(tmp_path / "result.xlsx")
    _create_sample_testcase(path)

    update_row_status(path, "TC-001", "FAIL",
                      mismatch_fields=["nama", "status_polis"],
                      notes="Ada 2 field mismatch")

    wb = load_workbook(path)
    ws = wb.active
    for row in ws.iter_rows(min_row=2):
        if row[0].value == "TC-001":
            assert ws.cell(row[0].row, 5).value == "FAIL"
            break


def test_fill_db_data(tmp_path):
    """Data DB ditulis ke kolom yang sesuai di baris policy."""
    path = str(tmp_path / "result.xlsx")
    _create_sample_testcase(path)

    fill_db_data(path, "510-7071457", {"insured_name": "Siti Rahayu"})

    wb = load_workbook(path)
    ws = wb.active
    headers = {cell.value: cell.column for cell in ws[1] if cell.value}

    for row in ws.iter_rows(min_row=2):
        if row[0].value == "TC-001":
            val = ws.cell(row[0].row, headers["insured_name"]).value
            assert val == "Siti Rahayu"
            break
