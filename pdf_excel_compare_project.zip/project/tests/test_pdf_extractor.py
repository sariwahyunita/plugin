"""tests/test_pdf_extractor.py"""

import pytest

from src.pdf_extractor import (
    _merge_continuation_rows,
    _parse_nilai_indonesia,
    extract_anchor_offset,
    extract_by_position,
    extract_regex,
)


def test_extract_regex_all_found(sample_pdf_text, sample_config):
    """Semua field ditemukan → semua value tidak None."""
    patterns = sample_config["pdf_patterns"]
    numeric  = set(sample_config["numeric_fields"])
    result   = extract_regex(sample_pdf_text, patterns, numeric)

    assert result["no_polis"]    == "510-7071457"
    assert result["status_polis"] == "Aktif"


def test_extract_regex_field_missing():
    """Field tidak ada di teks → value None, tidak crash."""
    result = extract_regex(
        full_text = "Teks tanpa field yang dicari",
        patterns  = {"no_polis": r"No\.\s*Polis\s*:\s*(\S+)"},
        numeric_fields = set(),
    )
    assert result["no_polis"] is None


def test_extract_regex_numeric_strip(sample_config):
    """Nilai numerik Rupiah di-strip dengan benar."""
    text     = "Uang Pertanggungan  : Rp. 18.750.000,00"
    patterns = {"uang_pertanggungan": r"Uang Pertanggungan\s*:\s*Rp\.\s*([\d.,]+)"}
    numeric  = {"uang_pertanggungan"}
    result   = extract_regex(text, patterns, numeric)

    assert result["uang_pertanggungan"] == "18750000"


def test_extract_anchor_offset_found(sample_pdf_text, sample_config):
    """Anchor 'Kepada Yth.' ditemukan → nama dan alamat ter-extract."""
    result = extract_anchor_offset(sample_pdf_text, sample_config["anchor_left"])
    assert result["nama_tujuan"] is not None
    assert "SITI" in result["nama_tujuan"].upper()


def test_extract_anchor_offset_not_found():
    """Anchor tidak ada → semua field None."""
    result = extract_anchor_offset("Teks tanpa anchor", {
        "anchor_text": "Kepada Yth.",
        "nama_offset": 1,
        "alamat_start": 2,
        "kota_pattern": "^JAKARTA",
    })
    assert result["nama_tujuan"] is None
    assert result["kota"] is None


def test_extract_post_processing_negative():
    """Nilai format kurung → float negatif."""
    assert _parse_nilai_indonesia("(345.000,00)") == -345000.0
    assert _parse_nilai_indonesia("(25.000,00)")  == -25000.0


def test_extract_post_processing_positive():
    """Nilai positif Indonesia → float positif."""
    assert _parse_nilai_indonesia("27.822,1644") == 27822.1644
    assert _parse_nilai_indonesia("15.000.000,00") == 15000000.0


def test_extract_post_processing_merge_continuation():
    """Baris continuation digabung ke baris data sebelumnya."""
    raw_rows = [
        ["28 September 2009", "Biaya Lump Sum", "29 September 2009", "", "", ""],
        ["",                  "Diawal",         "",                  "", "", ""],
    ]
    result = _merge_continuation_rows(raw_rows)
    assert len(result) == 1
    assert "Biaya Lump Sum Diawal" in result[0][1]


def test_extract_by_position():
    """Positional extract: ambil baris sesuai urutan."""
    text = "DATA TERTANGGUNG\nSiti Rahayu\nPerempuan, 34 Tahun\nJl. Kebon Jeruk\nJakarta"
    result = extract_by_position(
        full_text      = text,
        section_header = "DATA TERTANGGUNG",
        field_order    = ["nama", "gender_usia", "alamat"],
    )
    assert result["nama"]       == "Siti Rahayu"
    assert result["gender_usia"] == "Perempuan, 34 Tahun"
