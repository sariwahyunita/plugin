"""tests/test_pdf_locator.py"""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from src.pdf_locator import find_pdf, validate_pdf


def test_find_pdf_found(tmp_path):
    """PDF ada di folder → return full path."""
    pdf = tmp_path / "laporan_510-7071457_mei2026.pdf"
    pdf.write_bytes(b"%PDF-1.4")
    result = find_pdf("510-7071457", str(tmp_path))
    assert result == str(pdf)


def test_find_pdf_not_found(tmp_path):
    """PDF tidak ada → return None."""
    result = find_pdf("510-9999999", str(tmp_path))
    assert result is None


def test_find_pdf_case_insensitive(tmp_path):
    """Pencarian tidak case-sensitive."""
    pdf = tmp_path / "Laporan_510-7071457.pdf"
    pdf.write_bytes(b"%PDF-1.4")
    result = find_pdf("510-7071457", str(tmp_path))
    assert result is not None
    assert "510-7071457" in result


def test_find_pdf_multiple_match(tmp_path):
    """Lebih dari 1 file cocok → log warning, return yang pertama."""
    pdf1 = tmp_path / "laporan_510-7071457_jan.pdf"
    pdf2 = tmp_path / "laporan_510-7071457_feb.pdf"
    pdf1.write_bytes(b"%PDF-1.4")
    pdf2.write_bytes(b"%PDF-1.4")

    result = find_pdf("510-7071457", str(tmp_path))
    assert result is not None


def test_find_pdf_folder_not_exists():
    """Folder tidak ada → return None."""
    result = find_pdf("510-7071457", "/path/tidak/ada")
    assert result is None


def test_validate_pdf_valid(tmp_path):
    """PDF valid → return True."""
    pdf_path = str(tmp_path / "test.pdf")
    mock_page = MagicMock()
    mock_page.extract_text.return_value = "Test content"
    mock_pdf   = MagicMock()
    mock_pdf.pages = [mock_page]
    mock_pdf.__enter__ = MagicMock(return_value=mock_pdf)
    mock_pdf.__exit__  = MagicMock(return_value=False)

    with patch("src.pdf_locator.pdfplumber.open", return_value=mock_pdf):
        result = validate_pdf(pdf_path)
    assert result is True


def test_validate_pdf_corrupt(tmp_path):
    """PDF corrupt → return False."""
    pdf_path = str(tmp_path / "corrupt.pdf")
    with patch("src.pdf_locator.pdfplumber.open", side_effect=Exception("corrupt")):
        result = validate_pdf(pdf_path)
    assert result is False
