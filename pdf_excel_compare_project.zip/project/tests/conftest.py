"""
tests/conftest.py
Shared pytest fixtures untuk semua test files.
"""

import pytest
import pandas as pd


@pytest.fixture
def sample_config() -> dict:
    """Config mock untuk produk axa_mandiri."""
    return {
        "metadata": {"product_name": "AXA Mandiri", "product_code": "axa_mandiri"},
        "key_column": "policy_number",
        "extract_strategy": {
            "header_left": "anchor_offset",
            "header_right": "regex",
        },
        "column_crop": {
            "left":  [0,   0, 0.5, 1],
            "right": [0.5, 0, 1,   1],
        },
        "anchor_left": {
            "anchor_text": "Kepada Yth.",
            "nama_offset": 1,
            "alamat_start": 2,
            "kota_pattern": "^(JAKARTA|BANDUNG)",
        },
        "pdf_patterns": {
            "no_polis":           r"No\.\s*Polis\s*:\s*(\S+)",
            "tertanggung":        r"Tertanggung\s*:\s*(.+?)(?:\n)",
            "status_polis":       r"Status Polis\s*:\s*(\w+)",
            "uang_pertanggungan": r"Uang Pertanggungan\s*:\s*Rp\.\s*([\d.,]+)",
        },
        "excel_column_map": {
            "no_polis":           "no_polis",
            "tertanggung":        "insured_name",
            "status_polis":       "policy_status",
            "uang_pertanggungan": "sum_insured",
        },
        "numeric_fields": ["uang_pertanggungan"],
        "transaction_table_columns": [
            "tanggal_transaksi", "jenis_transaksi",
            "jumlah_unit", "harga_unit", "jumlah_nilai_transaksi",
        ],
        "transaction_key_columns": ["tanggal_transaksi", "jenis_transaksi"],
    }


@pytest.fixture
def sample_pdf_text() -> str:
    """Teks mock hasil extract PDF — simulasi dokumen AXA Mandiri."""
    return """
Kepada Yth.
IBU SITI RAHAYU
JL.DANAU SUNTER BARAT NO.5
TANJUNG PRIOK
JAKARTA UTARA 14350

No. Polis           : 510-7071457
Tertanggung         : Siti Rahayu
Jumlah Premi Top Up Tunggal : Rp. 0,00
Status Polis        : Aktif
Tanggal Mulai Asuransi : 28 September 2009
Nama Produk         : Mandiri Investasi Sejahtera
Uang Pertanggungan  : Rp. 18.750.000,00
Tanggal Cetak Laporan : 11 Mei 2026
"""


@pytest.fixture
def sample_db_data() -> dict:
    """Data mock dari hasil query DB."""
    return {
        "no_polis":      "510-7071457",
        "insured_name":  "Siti Rahayu",
        "policy_status": "Aktif",
        "start_date":    "28 September 2009",
        "product_name":  "Mandiri Investasi Sejahtera",
        "sum_insured":   "18750000",
    }


@pytest.fixture
def sample_df_pdf() -> pd.DataFrame:
    """DataFrame mock hasil extract tabel transaksi dari PDF."""
    return pd.DataFrame([
        {
            "tanggal_transaksi": "28 September 2009",
            "jenis_transaksi":   "Lump Sum Awal",
            "jumlah_unit":       27822.1644,
            "harga_unit":        539.1385,
            "jumlah_nilai_transaksi": 15000000.0,
        },
        {
            "tanggal_transaksi": "28 September 2009",
            "jenis_transaksi":   "Biaya Admin",
            "jumlah_unit":       -48.6887,
            "harga_unit":        513.4652,
            "jumlah_nilai_transaksi": -25000.0,
        },
    ])


@pytest.fixture
def sample_df_excel() -> pd.DataFrame:
    """DataFrame mock data transaksi dari DB."""
    return pd.DataFrame([
        {
            "tanggal_transaksi": "28 September 2009",
            "jenis_transaksi":   "Lump Sum Awal",
            "jumlah_unit":       27822.1644,
            "harga_unit":        539.1385,
            "jumlah_nilai_transaksi": 15000000.0,
        },
        {
            "tanggal_transaksi": "28 September 2009",
            "jenis_transaksi":   "Biaya Admin",
            "jumlah_unit":       -48.6887,
            "harga_unit":        513.4652,
            "jumlah_nilai_transaksi": -25000.0,  # sengaja sama untuk test PASS
        },
    ])
